import type { Access, CollectionBeforeValidateHook, CollectionConfig, FieldAccess } from 'payload'
import { passwordResetEmailHTML } from '../lib/password-reset-email'

const isAppUser = (user: { collection?: string } | null | undefined) => user?.collection === 'users'

const ownProfile: Access = ({ req }) => {
  const user = req.user
  return isAppUser(user) && user ? { id: { equals: user.id } } : false
}

const readOwnEmail: FieldAccess = ({ id, req }) => {
  const user = req.user
  return isAppUser(user) && user ? String(user.id) === String(id) : false
}

const enforceCreatorAvailability: CollectionBeforeValidateHook = ({ data, originalDoc }) => {
  const role = data?.role ?? originalDoc?.role
  return role === 'creator' ? data : { ...data, availableForWork: false }
}

export const Users: CollectionConfig = {
  slug: 'users',
  auth: {
    forgotPassword: {
      expiration: 60 * 60 * 1000,
      minRequestInterval: 60 * 1000,
      generateEmailHTML: ({ token } = {}) => passwordResetEmailHTML(token),
      generateEmailSubject: () => 'Reset your Atelier Network password',
    },
  },
  admin: {
    hidden: false,
    useAsTitle: 'name',
  },
  access: {
    create: () => true,
    delete: ownProfile,
    read: () => true,
    update: ownProfile,
  },
  hooks: {
    beforeValidate: [enforceCreatorAvailability],
  },
  fields: [
    {
      name: 'email',
      type: 'email',
      access: {
        read: readOwnEmail,
      },
    },
    {
      name: 'role',
      type: 'select',
      required: true,
      options: [
        { label: 'Creator', value: 'creator' },
        { label: 'Organization', value: 'organization' },
      ],
    },
    {
      name: 'name',
      type: 'text',
      required: true,
      maxLength: 100,
    },
    {
      name: 'phone',
      type: 'text',
      maxLength: 24,
      access: {
        read: readOwnEmail,
      },
    },
    {
      name: 'profileImage',
      type: 'upload',
      relationTo: 'media',
    },
    {
      name: 'availableForWork',
      type: 'checkbox',
      defaultValue: false,
      admin: {
        condition: (_, siblingData) => siblingData.role === 'creator',
        description: 'Show an availability badge on this creator profile.',
      },
    },
    {
      name: 'noticeTitle',
      type: 'text',
      maxLength: 140,
    },
    {
      name: 'noticeBody',
      type: 'textarea',
      maxLength: 600,
    },
    {
      name: 'tags',
      type: 'array',
      maxRows: 20,
      fields: [{ name: 'tag', type: 'text', required: true, maxLength: 40 }],
    },
    {
      name: 'description',
      type: 'textarea',
      maxLength: 2000,
    },
    {
      name: 'location',
      type: 'text',
      maxLength: 120,
    },
    {
      name: 'portfolio',
      type: 'upload',
      relationTo: 'media',
      hasMany: true,
      maxRows: 24,
    },
  ],
  versions: false,
}
