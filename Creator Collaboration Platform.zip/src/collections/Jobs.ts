import type { Access, CollectionBeforeValidateHook, CollectionConfig, Where } from 'payload'

const isAdmin = (user: { collection?: string } | null | undefined) => user?.collection === 'admins'

const isAppUser = (user: { collection?: string } | null | undefined) => user?.collection === 'users'

const readJobs: Access = ({ req }) => {
  const user = req.user
  if (isAdmin(user)) return true
  if (isAppUser(user) && user) {
    const where: Where = {
      or: [{ status: { equals: 'published' } }, { owner: { equals: user.id } }],
    }
    return where
  }
  return { status: { equals: 'published' } }
}

const ownJobs: Access = ({ req }) => {
  const user = req.user
  if (isAdmin(user)) return true
  return isAppUser(user) && user ? { owner: { equals: user.id } } : false
}

const setOwner: CollectionBeforeValidateHook = ({ data, operation, req }) => {
  const user = req.user
  if (operation === 'create' && isAppUser(user) && user) {
    return { ...data, owner: user.id }
  }
  return data
}

export const Jobs: CollectionConfig = {
  slug: 'jobs',
  admin: {
    group: 'Atelier Network',
    useAsTitle: 'title',
    defaultColumns: ['title', 'posterName', 'listingType', 'status', 'createdAt'],
  },
  access: {
    create: ({ req }) => isAdmin(req.user) || isAppUser(req.user),
    delete: ownJobs,
    read: readJobs,
    update: ownJobs,
  },
  hooks: {
    beforeValidate: [setOwner],
  },
  fields: [
    {
      name: 'title',
      type: 'text',
      required: true,
      maxLength: 140,
    },
    {
      name: 'slug',
      type: 'text',
      required: true,
      unique: true,
      index: true,
      maxLength: 180,
    },
    {
      name: 'owner',
      type: 'relationship',
      relationTo: 'users',
      access: {
        create: () => false,
        update: () => false,
      },
    },
    {
      name: 'posterName',
      type: 'text',
      required: true,
      maxLength: 100,
    },
    {
      name: 'listingType',
      type: 'select',
      required: true,
      options: [
        { label: 'Hiring', value: 'hiring' },
        { label: 'For Hire', value: 'for-hire' },
      ],
    },
    {
      name: 'location',
      type: 'text',
      required: true,
      maxLength: 120,
    },
    {
      name: 'compensation',
      type: 'text',
      required: true,
      maxLength: 120,
    },
    {
      name: 'description',
      type: 'textarea',
      required: true,
      maxLength: 5000,
    },
    {
      name: 'tags',
      type: 'array',
      maxRows: 20,
      fields: [{ name: 'tag', type: 'text', required: true, maxLength: 40 }],
    },
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'published',
      options: [
        { label: 'Published', value: 'published' },
        { label: 'Draft', value: 'draft' },
      ],
    },
  ],
  versions: false,
}
