import type { CollectionConfig } from 'payload'

import { createFolderField, createTagField } from 'payload'

export const Media: CollectionConfig = {
  slug: 'media',
  access: {
    create: ({ req }) => req.user?.collection === 'admins' || req.user?.collection === 'users',
    delete: ({ req }) => {
      if (req.user?.collection === 'admins') return true
      return req.user?.collection === 'users' ? { owner: { equals: req.user.id } } : false
    },
    read: () => true,
    update: ({ req }) => {
      if (req.user?.collection === 'admins') return true
      return req.user?.collection === 'users' ? { owner: { equals: req.user.id } } : false
    },
  },
  hooks: {
    beforeValidate: [
      ({ data, operation, req }) => {
        if (operation === 'create' && req.user?.collection === 'users') {
          return { ...data, owner: req.user.id }
        }
        return data
      },
    ],
  },
  fields: [
    {
      name: 'alt',
      type: 'text',
      required: true,
    },
    {
      name: 'owner',
      type: 'relationship',
      relationTo: 'users',
      admin: {
        position: 'sidebar',
      },
      access: {
        create: () => false,
        update: () => false,
      },
    },
    createFolderField({ relationTo: 'folders' }),
    createTagField({ relationTo: 'tags' }),
  ],
  upload: {
    mimeTypes: ['image/*', 'video/*', 'audio/*'],
    modifyResponseHeaders: ({ headers }) => {
      headers.set('Cache-Control', 'public, max-age=3600, s-maxage=3600')
      return headers
    },
  },
}
