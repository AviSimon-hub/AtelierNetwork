import type { Access, CollectionBeforeValidateHook, CollectionConfig, Where } from 'payload'

const isAdmin = (user: { collection?: string } | null | undefined) => user?.collection === 'admins'

const isAppUser = (user: { collection?: string } | null | undefined) => user?.collection === 'users'

const participantOnly: Access = ({ req }) => {
  const user = req.user
  if (isAdmin(user)) return true
  if (!isAppUser(user) || !user) return false
  const where: Where = {
    or: [{ sender: { equals: user.id } }, { recipient: { equals: user.id } }],
  }
  return where
}

const setSender: CollectionBeforeValidateHook = ({ data, operation, req }) => {
  const user = req.user
  if (operation === 'create' && isAppUser(user) && user) {
    return { ...data, sender: user.id }
  }
  return data
}

export const Messages: CollectionConfig = {
  slug: 'messages',
  admin: {
    group: 'Atelier Network',
    useAsTitle: 'subject',
  },
  access: {
    create: ({ req }) => isAppUser(req.user),
    delete: participantOnly,
    read: participantOnly,
    update: participantOnly,
  },
  hooks: {
    beforeValidate: [setSender],
  },
  fields: [
    {
      name: 'sender',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      access: {
        create: () => false,
        update: () => false,
      },
    },
    {
      name: 'recipient',
      type: 'relationship',
      relationTo: 'users',
      required: true,
      access: {
        update: () => false,
      },
    },
    {
      name: 'subject',
      type: 'text',
      required: true,
      maxLength: 140,
    },
    {
      name: 'body',
      type: 'textarea',
      required: true,
      maxLength: 5000,
    },
    {
      name: 'readAt',
      type: 'date',
    },
  ],
  versions: false,
}
