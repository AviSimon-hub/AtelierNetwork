import Link from 'next/link'

export default function SiteHeader({
  active,
}: {
  active?: 'creators' | 'organizations' | 'jobs' | 'account'
}) {
  return (
    <header className="site-header">
      <Link href="/" className="wordmark" aria-label="Atelier Network">
        <span className="brand-main" aria-hidden="true">
          Atelier
        </span>
        <span className="brand-network" aria-hidden="true">
          network
        </span>
      </Link>
      <nav aria-label="Primary navigation">
        <Link className={active === 'creators' ? 'active' : undefined} href="/creators">
          creators
        </Link>
        <Link className={active === 'organizations' ? 'active' : undefined} href="/organizations">
          organizations
        </Link>
        <Link className={active === 'jobs' ? 'active' : undefined} href="/jobs">
          jobs
        </Link>
        <Link className={active === 'account' ? 'active' : undefined} href="/account">
          my account
        </Link>
      </nav>
    </header>
  )
}
