'use client'

import { createContext, type FormEvent, type ReactNode, useContext, useMemo, useState } from 'react'
import Link from 'next/link'
import { usePathname, useRouter, useSearchParams as useNextSearchParams } from 'next/navigation'
import type { RegisteredProfile } from '@/lib/public-profiles'
function useLocation() {
  const pathname = usePathname()
  const params = useNextSearchParams()
  return { pathname, search: params.size ? `?${params.toString()}` : '' }
}

function useNavigate() {
  const router = useRouter()
  return (href: string) => router.push(href)
}

function useMutableSearchParams(): [URLSearchParams, (next: URLSearchParams) => void] {
  const pathname = usePathname()
  const params = useNextSearchParams()
  const router = useRouter()
  return [
    new URLSearchParams(params.toString()),
    (next) => router.push(`${pathname}${next.size ? `?${next.toString()}` : ''}`),
  ]
}

function NavLink({ to, children }: { to: string; children: ReactNode }) {
  const pathname = usePathname()
  return (
    <Link href={to} className={pathname === to ? 'active' : undefined}>
      {children}
    </Link>
  )
}

function useParams() {
  const parts = usePathname().split('/').filter(Boolean)
  return {
    creatorId: parts[0] === 'creators' ? parts[1] : undefined,
    jobId: parts[0] === 'jobs' ? parts[1] : undefined,
    organizationId: parts[0] === 'organizations' ? parts[1] : undefined,
  }
}

type Creator = {
  id: string
  name: string
  discipline: string
  city: string
  available: boolean
  bio: string
  tags: string[]
  photo?: string
  profileHref?: string
  bulletin: {
    title: string
    detail: string
    date: string
  }
}

type Job = {
  id: string
  title: string
  company: string
  location: string
  posted: string
  compensation: string
  description: string
  tags: string[]
  listingType: 'hiring' | 'for hire'
  organizationId?: string
  creatorId?: string
}

type Organization = {
  id: string
  name: string
  type: string
  city: string
  about: string
  website: string
  photo?: string
  tags: string[]
  profileHref?: string
}

type SearchScope = 'creators' | 'jobs' | 'organizations'

const creators: Creator[] = []

const organizations: Organization[] = []

const jobs: Job[] = []

const allCreatorTags = [...new Set(creators.flatMap((creator) => creator.tags))].sort()
const allJobTags = [...new Set(jobs.flatMap((job) => job.tags))].sort()
const allOrganizationTags = [
  ...new Set(organizations.flatMap((organization) => organization.tags)),
].sort()

const RegisteredProfilesContext = createContext<RegisteredProfile[]>([])

function useDirectoryData() {
  const registeredProfiles = useContext(RegisteredProfilesContext)
  const registeredCreators: Creator[] = registeredProfiles
    .filter((profile) => profile.role === 'creator')
    .map((profile) => ({
      id: profile.id,
      name: profile.name,
      discipline: profile.tags.slice(0, 2).join(' · ') || 'Creator',
      city: profile.location || 'Location not listed',
      available: profile.availableForWork,
      bio: profile.description || 'This creator has not added a description yet.',
      tags: profile.tags,
      photo: profile.profileImageURL || undefined,
      profileHref: `/profiles/${profile.id}`,
      bulletin: {
        title: profile.noticeTitle || '',
        detail: profile.noticeBody || '',
        date: '',
      },
    }))
  const registeredOrganizations: Organization[] = registeredProfiles
    .filter((profile) => profile.role === 'organization')
    .map((profile) => ({
      id: profile.id,
      name: profile.name,
      type: profile.tags.slice(0, 2).join(' · ') || 'Organization',
      city: profile.location || 'Location not listed',
      about: profile.description || 'This organization has not added a description yet.',
      website: '',
      photo: profile.profileImageURL || undefined,
      tags: profile.tags,
      profileHref: `/profiles/${profile.id}`,
    }))

  return {
    allCreators: [...registeredCreators, ...creators],
    allOrganizations: [...registeredOrganizations, ...organizations],
  }
}

const tagTaxonomy = [
  {
    name: 'Music & audio',
    tags: ['music', 'electronic', 'audio', 'sound design'],
  },
  {
    name: 'Visual art',
    tags: ['painting', 'murals', 'sculpture', 'installation', 'illustration', 'public art'],
  },
  { name: 'Fashion', tags: ['fashion', 'art direction'] },
  {
    name: 'Film & photography',
    tags: ['film', 'photography', 'portraits', 'editorial', 'animation'],
  },
  { name: 'Writing', tags: ['writing', 'narrative', 'branding'] },
  {
    name: 'Games & interactive',
    tags: ['games', 'game art', 'game design', 'Unity', '3D', 'indie', 'concept art'],
  },
  { name: 'Design & production', tags: ['set design'] },
  { name: 'Work type', tags: ['hiring', 'for hire', 'freelance', 'contract'] },
  {
    name: 'Organization type',
    tags: [
      'record label',
      'creative studio',
      'game studio',
      'film studio',
      'gallery',
      'project space',
      'music venue',
      'production',
    ],
  },
  {
    name: 'Focus',
    tags: ['documentary', 'experimental', 'performance', 'audiovisual', 'independent'],
  },
]

function SiteLayout() {
  const { pathname, search } = useLocation()
  const isHome = pathname === '/'
  const toolbarType: SearchScope = pathname.startsWith('/jobs')
    ? 'jobs'
    : pathname.startsWith('/organizations')
      ? 'organizations'
      : 'creators'
  const toolbarParams = new URLSearchParams(search)

  return (
    <div className="min-h-screen bg-[#f4f4f4] text-[#111]">
      <header className={`site-header ${!isHome ? 'home-toolbar' : ''}`}>
        <Link href="/" className="wordmark" aria-label="Atelier Network">
          <span className="brand-main" aria-hidden="true">
            Atelier
          </span>
          <span className="brand-network" aria-hidden="true">
            network
          </span>
        </Link>
        {!isHome && (
          <SearchForm
            key={`${pathname}${search}`}
            toolbar
            initialType={toolbarType}
            initialScopes={toolbarParams.getAll('scope') as SearchScope[]}
            initialQuery={toolbarParams.get('q') ?? ''}
            initialTags={toolbarParams.getAll('tag')}
          />
        )}
        <nav aria-label="Primary navigation">
          <NavLink to="/creators">creators</NavLink>
          <NavLink to="/organizations">organizations</NavLink>
          <NavLink to="/jobs">jobs</NavLink>
          <a href="/account">my account</a>
        </nav>
      </header>
      <Outlet />
    </div>
  )
}

function SearchForm({
  initialType = 'creators',
  initialScopes = [],
  initialQuery = '',
  initialTags = [],
  compact = false,
  toolbar = false,
}: {
  initialType?: 'creators' | 'jobs' | 'organizations'
  initialScopes?: SearchScope[]
  initialQuery?: string
  initialTags?: string[]
  compact?: boolean
  toolbar?: boolean
}) {
  const { allCreators, allOrganizations } = useDirectoryData()
  const navigate = useNavigate()
  const [scopes, setScopes] = useState<SearchScope[]>(
    initialScopes.length ? initialScopes : [initialType],
  )
  const [query, setQuery] = useState(initialQuery)
  const [tags, setTags] = useState<string[]>(initialTags)
  const singleScope = scopes.length === 1 ? scopes[0] : null
  const tagOptions = [
    ...new Set(
      scopes.flatMap((scope) =>
        scope === 'creators'
          ? [...new Set(allCreators.flatMap((creator) => creator.tags))]
          : scope === 'jobs'
            ? allJobTags
            : [...new Set(allOrganizations.flatMap((organization) => organization.tags))],
      ),
    ),
  ].sort()

  const submit = (event: FormEvent) => {
    event.preventDefault()
    const params = new URLSearchParams()
    if (query.trim()) params.set('q', query.trim())
    tags.forEach((tag) => params.append('tag', tag))
    if (scopes.length === 1) {
      navigate(`/${scopes[0]}${params.size ? `?${params.toString()}` : ''}`)
      return
    }
    scopes.forEach((scope) => params.append('scope', scope))
    navigate(`/search?${params.toString()}`)
  }

  const toggleTag = (tag: string) => {
    setTags((current) =>
      current.includes(tag) ? current.filter((item) => item !== tag) : [...current, tag],
    )
  }

  if (toolbar) {
    return (
      <form className="toolbar-search" onSubmit={submit}>
        <details className="toolbar-multiselect">
          <summary>
            {scopes.length === 3
              ? 'all categories'
              : scopes.length === 1
                ? scopes[0]
                : `${scopes.length} categories`}
          </summary>
          <div className="toolbar-options">
            {(['creators', 'jobs', 'organizations'] as SearchScope[]).map((scope) => (
              <label key={scope}>
                <input
                  type="checkbox"
                  checked={scopes.includes(scope)}
                  onChange={() => {
                    setScopes((current) =>
                      current.includes(scope)
                        ? current.filter((item) => item !== scope)
                        : [...current, scope],
                    )
                    setTags([])
                  }}
                />
                {scope}
              </label>
            ))}
          </div>
        </details>
        <input
          aria-label="Search keywords"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search by keyword"
        />
        <details className="toolbar-multiselect tag-multiselect">
          <summary>
            {tags.length === 0 ? 'all tags' : tags.length === 1 ? tags[0] : `${tags.length} tags`}
          </summary>
          <div className="toolbar-options">
            <button type="button" className="clear-options" onClick={() => setTags([])}>
              all tags
            </button>
            {tagOptions.map((tag) => (
              <label key={tag}>
                <input
                  type="checkbox"
                  checked={tags.includes(tag)}
                  onChange={() => toggleTag(tag)}
                />
                {tag}
              </label>
            ))}
          </div>
        </details>
        <button type="submit" disabled={!scopes.length}>
          search
        </button>
      </form>
    )
  }

  return (
    <form className={compact ? 'search-form compact' : 'search-form'} onSubmit={submit}>
      {!compact && <h1>Find creative work and the people who make it.</h1>}
      <div className="search-row">
        <label className="query-field">
          <span>keywords</span>
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={
              singleScope === 'creators'
                ? 'name, skill, or location'
                : singleScope === 'jobs'
                  ? 'title, company, or location'
                  : singleScope === 'organizations'
                    ? 'organization name, type, or location'
                    : 'names, skills, titles, or locations'
            }
          />
        </label>
        <button type="submit" disabled={!scopes.length}>
          search
        </button>
      </div>
      <fieldset className="search-scope">
        <legend>search for</legend>
        {(
          [
            ['creators', 'creators'],
            ['jobs', 'jobs'],
            ['organizations', 'organizations'],
          ] as const
        ).map(([value, label]) => (
          <label key={value}>
            <input
              type="checkbox"
              checked={scopes.includes(value)}
              onChange={() => {
                setScopes((current) =>
                  current.includes(value)
                    ? current.filter((scope) => scope !== value)
                    : [...current, value],
                )
                setTags([])
              }}
            />
            {label}
          </label>
        ))}
      </fieldset>
      {!compact && tagOptions.length > 0 && (
        <fieldset className="tag-picker">
          <legend>
            include tags <small>(optional)</small>
          </legend>
          <div>
            {tagOptions.map((tag) => (
              <label key={tag} className={tags.includes(tag) ? 'selected' : ''}>
                <input
                  type="checkbox"
                  checked={tags.includes(tag)}
                  onChange={() => toggleTag(tag)}
                />
                {tag}
              </label>
            ))}
          </div>
        </fieldset>
      )}
    </form>
  )
}

function CombinedSearchPage() {
  const { allCreators, allOrganizations } = useDirectoryData()
  const params = useNextSearchParams()
  const query = params.get('q') ?? ''
  const selectedScopes = params.getAll('scope') as SearchScope[]
  const selectedTags = params.getAll('tag')
  const scopes = selectedScopes.length
    ? selectedScopes
    : (['creators', 'jobs', 'organizations'] as SearchScope[])
  const matches = (value: string, itemTags: string[]) =>
    (!query || value.toLowerCase().includes(query.toLowerCase())) &&
    (!selectedTags.length || selectedTags.every((tag) => itemTags.includes(tag)))
  const matchingCreators = scopes.includes('creators')
    ? allCreators.filter((creator) =>
        matches(
          `${creator.name} ${creator.discipline} ${creator.city} ${creator.tags.join(' ')}`,
          creator.tags,
        ),
      )
    : []
  const matchingJobs = scopes.includes('jobs')
    ? jobs.filter((job) =>
        matches(`${job.title} ${job.company} ${job.location} ${job.tags.join(' ')}`, job.tags),
      )
    : []
  const matchingOrganizations = scopes.includes('organizations')
    ? allOrganizations.filter((organization) =>
        matches(
          `${organization.name} ${organization.type} ${organization.city} ${organization.about} ${organization.tags.join(' ')}`,
          organization.tags,
        ),
      )
    : []
  const total = matchingCreators.length + matchingJobs.length + matchingOrganizations.length

  return (
    <main className="results-page">
      <div className="breadcrumbs">
        <Link href="/">home</Link> › combined search
      </div>
      <div className="combined-heading">
        <h1>search results</h1>
        <span>
          {total} result{total === 1 ? '' : 's'} across {scopes.length} categories
        </span>
      </div>
      {matchingCreators.length > 0 && (
        <section className="combined-section">
          <h2>
            creators <Link href={`/creators?q=${encodeURIComponent(query)}`}>view all</Link>
          </h2>
          <div className="mixed-creator-grid">
            {matchingCreators.map((creator) => (
              <CreatorRow key={creator.id} creator={creator} />
            ))}
          </div>
        </section>
      )}
      {matchingJobs.length > 0 && (
        <section className="results-list combined-section">
          <div className="results-heading">
            <h2>jobs</h2>
            <Link href={`/jobs?q=${encodeURIComponent(query)}`}>view all</Link>
          </div>
          {matchingJobs.map((job) => (
            <JobRow key={job.id} job={job} />
          ))}
        </section>
      )}
      {matchingOrganizations.length > 0 && (
        <section className="results-list combined-section">
          <div className="results-heading">
            <h2>organizations</h2>
            <Link href={`/organizations?q=${encodeURIComponent(query)}`}>view all</Link>
          </div>
          {matchingOrganizations.map((organization) => (
            <article className="listing organization-listing" key={organization.id}>
              {organization.photo ? (
                <img className="organization-thumbnail" src={organization.photo} alt="" />
              ) : (
                <div className="organization-mark" aria-hidden="true">
                  {organization.name.slice(0, 2).toUpperCase()}
                </div>
              )}
              <div>
                <h2>
                  <Link href={organization.profileHref ?? `/organizations/${organization.id}`}>
                    {organization.name}
                  </Link>
                </h2>
                <p className="listing-meta">
                  {organization.type} · {organization.city}
                </p>
              </div>
            </article>
          ))}
        </section>
      )}
      {!total && (
        <p className="empty standalone">No matching results across the selected categories.</p>
      )}
    </main>
  )
}

function OrganizationResultsPage() {
  const { allOrganizations } = useDirectoryData()
  const [params, setParams] = useMutableSearchParams()
  const query = params.get('q') ?? ''
  const selectedTags = params.getAll('tag')
  const filtered = allOrganizations.filter(
    (organization) =>
      (!query ||
        `${organization.name} ${organization.type} ${organization.city} ${organization.about} ${organization.tags.join(' ')}`
          .toLowerCase()
          .includes(query.toLowerCase())) &&
      (!selectedTags.length || selectedTags.every((tag) => organization.tags.includes(tag))),
  )
  const setTags = (nextTags: string[]) => {
    const next = new URLSearchParams(params)
    next.delete('tag')
    nextTags.forEach((tag) => next.append('tag', tag))
    setParams(next)
  }

  return (
    <main className="results-page">
      <div className="breadcrumbs">
        <Link href="/">home</Link> › organizations
      </div>
      <div className="results-layout">
        <TagFilters
          tags={[...new Set(allOrganizations.flatMap((organization) => organization.tags))].sort()}
          selected={selectedTags}
          onChange={setTags}
        />
        <section className="results-list">
          <div className="results-heading">
            <h1>organizations</h1>
            <span>
              {filtered.length} result{filtered.length === 1 ? '' : 's'}
            </span>
          </div>
          {selectedTags.length > 0 && (
            <div className="active-filters">
              filtered by:{' '}
              {selectedTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setTags(selectedTags.filter((item) => item !== tag))}
                >
                  {tag} ×
                </button>
              ))}
            </div>
          )}
          {filtered.length === 0 && (
            <p className="empty">No matching organizations. Try changing your search.</p>
          )}
          {filtered.map((organization) => (
            <article className="listing organization-listing" key={organization.id}>
              {organization.photo ? (
                <img
                  className="organization-thumbnail"
                  src={organization.photo}
                  alt={`${organization.name} profile`}
                />
              ) : (
                <div className="organization-mark" aria-hidden="true">
                  {organization.name.slice(0, 2).toUpperCase()}
                </div>
              )}
              <div>
                <h2>
                  <Link href={organization.profileHref ?? `/organizations/${organization.id}`}>
                    {organization.name}
                  </Link>
                </h2>
                <p className="listing-meta">
                  {organization.type} · {organization.city}
                </p>
                <p>{organization.about}</p>
                <div className="tags">
                  {organization.tags.map((tag) => (
                    <Link key={tag} href={`/organizations?tag=${encodeURIComponent(tag)}`}>
                      {tag}
                    </Link>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </section>
      </div>
    </main>
  )
}

function HomePage() {
  return (
    <main className="home-page">
      <SearchForm />
    </main>
  )
}

function TagFilters({
  tags,
  selected,
  onChange,
}: {
  tags: string[]
  selected: string[]
  onChange: (tags: string[]) => void
}) {
  const [tagQuery, setTagQuery] = useState('')
  const groupedTags = tagTaxonomy
    .map((category) => ({
      ...category,
      tags: category.tags.filter((tag) => tags.includes(tag)),
    }))
    .filter((category) => category.tags.length > 0)
  const categorizedTags = new Set(groupedTags.flatMap((category) => category.tags))
  const otherTags = tags.filter((tag) => !categorizedTags.has(tag))
  if (otherTags.length) groupedTags.push({ name: 'Other', tags: otherTags })
  const suggestions = tagQuery.trim()
    ? tags
        .filter(
          (tag) =>
            !selected.includes(tag) && tag.toLowerCase().includes(tagQuery.trim().toLowerCase()),
        )
        .sort(
          (a, b) =>
            Number(b.toLowerCase().startsWith(tagQuery.toLowerCase())) -
            Number(a.toLowerCase().startsWith(tagQuery.toLowerCase())),
        )
        .slice(0, 6)
    : []

  const selectSuggestedTag = (tag: string) => {
    onChange([...selected, tag])
    setTagQuery('')
  }

  return (
    <aside className="filters">
      <div className="panel-title">filter by tag</div>
      <div className="tag-search">
        <label htmlFor="tag-filter-search">find a tag</label>
        <input
          id="tag-filter-search"
          value={tagQuery}
          onChange={(event) => setTagQuery(event.target.value)}
          placeholder="try “music” or “photo”"
          autoComplete="off"
          aria-autocomplete="list"
          aria-controls="tag-suggestions"
        />
        {tagQuery.trim() && (
          <div className="tag-suggestions" id="tag-suggestions" role="listbox">
            {suggestions.length ? (
              suggestions.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  role="option"
                  onClick={() => selectSuggestedTag(tag)}
                >
                  <span>{tag}</span>
                  <small>
                    {tagTaxonomy.find((category) => category.tags.includes(tag))?.name ?? 'Other'}
                  </small>
                </button>
              ))
            ) : (
              <p>no matching tags</p>
            )}
          </div>
        )}
      </div>
      <button
        className={`all-tags ${!selected.length ? 'active' : ''}`}
        onClick={() => onChange([])}
      >
        all disciplines
      </button>
      <div className="filter-groups">
        {groupedTags.map((category) => (
          <details
            className="filter-group"
            key={category.name}
            open={category.tags.some((tag) => selected.includes(tag))}
          >
            <summary>
              {category.name}
              <span>
                {category.tags.filter((tag) => selected.includes(tag)).length ||
                  category.tags.length}
              </span>
            </summary>
            <div>
              {category.tags.map((tag) => (
                <label key={tag} className={selected.includes(tag) ? 'active' : ''}>
                  <input
                    type="checkbox"
                    checked={selected.includes(tag)}
                    onChange={() =>
                      onChange(
                        selected.includes(tag)
                          ? selected.filter((item) => item !== tag)
                          : [...selected, tag],
                      )
                    }
                  />
                  {tag}
                </label>
              ))}
            </div>
          </details>
        ))}
      </div>
    </aside>
  )
}

function ResultsPage({ kind }: { kind: 'creators' | 'jobs' }) {
  const { allCreators } = useDirectoryData()
  const [params, setParams] = useMutableSearchParams()
  const query = params.get('q') ?? ''
  const selectedTags = params.getAll('tag')
  const source = kind === 'creators' ? allCreators : jobs
  const tags =
    kind === 'creators'
      ? [...new Set(allCreators.flatMap((creator) => creator.tags))].sort()
      : allJobTags

  const filtered = useMemo(
    () =>
      source.filter((item) => {
        const searchable =
          kind === 'creators'
            ? `${(item as Creator).name} ${(item as Creator).discipline} ${(item as Creator).city} ${item.tags.join(' ')}`
            : `${(item as Job).title} ${(item as Job).company} ${(item as Job).location} ${item.tags.join(' ')}`
        return (
          (!query || searchable.toLowerCase().includes(query.toLowerCase())) &&
          (!selectedTags.length || selectedTags.every((tag) => item.tags.includes(tag)))
        )
      }),
    [kind, query, selectedTags, source],
  )

  const setTags = (nextTags: string[]) => {
    const next = new URLSearchParams(params)
    next.delete('tag')
    nextTags.forEach((tag) => next.append('tag', tag))
    setParams(next)
  }

  return (
    <main className="results-page">
      <div className="breadcrumbs">
        <Link href="/">home</Link> › {kind}
      </div>
      <div className="results-layout">
        <TagFilters tags={tags} selected={selectedTags} onChange={setTags} />
        <section className={`results-list ${kind === 'creators' ? 'creator-results' : ''}`}>
          <div className="results-heading">
            <h1>{kind === 'creators' ? 'creators' : 'jobs'}</h1>
            <span>
              {filtered.length} result{filtered.length === 1 ? '' : 's'}
            </span>
          </div>
          {selectedTags.length > 0 && (
            <div className="active-filters">
              filtered by:{' '}
              {selectedTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setTags(selectedTags.filter((item) => item !== tag))}
                >
                  {tag} ×
                </button>
              ))}
            </div>
          )}
          {filtered.length === 0 && (
            <p className="empty">
              No matching listings. Try removing a tag or changing your search.
            </p>
          )}
          {kind === 'creators'
            ? (filtered as Creator[]).map((creator) => (
                <CreatorRow key={creator.id} creator={creator} />
              ))
            : (filtered as Job[]).map((job) => <JobRow key={job.id} job={job} />)}
        </section>
      </div>
    </main>
  )
}

function CreatorRow({ creator }: { creator: Creator }) {
  const href = creator.profileHref ?? `/creators/${creator.id}`
  return (
    <article className="listing creator-listing">
      <Link href={href} className="creator-photo-link">
        {creator.photo ? (
          <img
            className="creator-photo"
            src={creator.photo}
            alt={`${creator.name}, ${creator.discipline}`}
          />
        ) : (
          <span className="grid h-full place-items-center bg-[#7b4ab5] text-5xl font-extralight text-white">
            {creator.name.slice(0, 1).toUpperCase()}
          </span>
        )}
      </Link>
      <div className="creator-card-copy">
        <h2>
          <Link href={href}>{creator.name}</Link>
        </h2>
        <p className="creator-discipline">{creator.discipline}</p>
        <p className="listing-meta">{creator.city}</p>
        {creator.available && <span className="status">available</span>}
      </div>
    </article>
  )
}

function JobRow({ job }: { job: Job }) {
  const ownerPath = job.organizationId
    ? `/organizations/${job.organizationId}`
    : `/creators/${job.creatorId}`
  return (
    <article className="listing job-listing">
      <time>
        <strong className={`listing-type ${job.listingType === 'for hire' ? 'for-hire' : ''}`}>
          {job.listingType}
        </strong>
        {job.posted}
      </time>
      <div>
        <h2>
          <Link href={`/jobs/${job.id}`}>{job.title}</Link>
        </h2>
        <p className="listing-meta">
          <Link href={ownerPath}>{job.company}</Link> · {job.location} · {job.compensation}
        </p>
        <p>{job.description}</p>
        <div className="tags">
          {job.tags.map((tag) => (
            <Link key={tag} href={`/jobs?tag=${encodeURIComponent(tag)}`}>
              {tag}
            </Link>
          ))}
        </div>
      </div>
    </article>
  )
}

function CreatorProfile() {
  const { creatorId } = useParams()
  const [uploadedMedia, setUploadedMedia] = useState<
    Array<{
      name: string
      type: string
      url: string
    }>
  >([])
  const creator = creators.find((item) => item.id === creatorId)
  if (!creator) return <NotFound />

  const addMedia = (files: FileList | null) => {
    if (!files) return
    setUploadedMedia((current) => [
      ...current,
      ...Array.from(files).map((file) => ({
        name: file.name,
        type: file.type,
        url: URL.createObjectURL(file),
      })),
    ])
  }

  return (
    <main className="detail-page">
      <div className="breadcrumbs">
        <Link href="/">home</Link> › <Link href="/creators">creators</Link> › {creator.name}
      </div>
      <div className="detail-card">
        <aside className="bulletin-board" aria-label={`${creator.name}'s notice board`}>
          <div className="bulletin-label">notice board</div>
          <div>
            <strong>{creator.bulletin.title}</strong>
            <p>{creator.bulletin.detail}</p>
          </div>
          <time>{creator.bulletin.date}</time>
        </aside>
        <div className="profile-heading">
          <img
            className="profile-picture"
            src={creator.photo}
            alt={`${creator.name}, ${creator.discipline}`}
          />
          <div>
            <h1>{creator.name}</h1>
            <p>
              {creator.discipline} · {creator.city}
            </p>
            {creator.available && <span className="status">available for work</span>}
          </div>
        </div>
        <section>
          <h2>about</h2>
          <p>{creator.bio}</p>
        </section>
        <section>
          <h2>skills and tags</h2>
          <p className="help-text">Select a tag to find more creators with that skill.</p>
          <div className="tags large-tags">
            {creator.tags.map((tag) => (
              <Link key={tag} href={`/creators?tag=${encodeURIComponent(tag)}`}>
                {tag}
              </Link>
            ))}
          </div>
        </section>
        <section>
          <h2>portfolio</h2>
          <p className="help-text">Profiles can include images, video reels, and audio work.</p>
          <div className="media-grid">
            <figure className="media-item media-photo">
              <img src={creator.photo} alt={`${creator.name} portfolio work`} />
              <figcaption>selected work · image</figcaption>
            </figure>
            <div className="media-item media-video">
              <img src={creator.photo} alt="" />
              <button aria-label={`Play ${creator.name}'s video reel`}>
                <span>▶</span>
              </button>
              <p>
                studio reel <small>video · 1:42</small>
              </p>
            </div>
            <div className="media-item media-audio">
              <button aria-label={`Play ${creator.name}'s audio work`}>▶</button>
              <div>
                <strong>selected audio work</strong>
                <small>audio · 03:18</small>
                <div className="waveform" aria-hidden="true">
                  ▂▅▃▇▄▆▂▅▇▃▆▄▂▇▅▃▆▂
                </div>
              </div>
            </div>
            {uploadedMedia.map((media) => (
              <figure className="media-item uploaded-media" key={media.url}>
                {media.type.startsWith('image/') && <img src={media.url} alt={media.name} />}
                {media.type.startsWith('video/') && (
                  <video src={media.url} controls aria-label={media.name} />
                )}
                {media.type.startsWith('audio/') && (
                  <audio src={media.url} controls aria-label={media.name} />
                )}
                <figcaption>{media.name}</figcaption>
              </figure>
            ))}
            <label className="add-media">
              + add image, video, or audio
              <input
                type="file"
                accept="image/*,video/*,audio/*"
                multiple
                onChange={(event) => addMedia(event.target.files)}
              />
            </label>
          </div>
        </section>
        <button className="contact-button">
          contact {creator.name.split(' ')[0].toLowerCase()}
        </button>
      </div>
    </main>
  )
}

function JobDetail() {
  const { jobId } = useParams()
  const job = jobs.find((item) => item.id === jobId)
  if (!job) return <NotFound />
  const ownerPath = job.organizationId
    ? `/organizations/${job.organizationId}`
    : `/creators/${job.creatorId}`

  return (
    <main className="detail-page">
      <div className="breadcrumbs">
        <Link href="/">home</Link> › <Link href="/jobs">jobs</Link> › {job.title}
      </div>
      <div className="detail-card job-detail">
        <p className="eyebrow">
          <strong className={`listing-type ${job.listingType === 'for hire' ? 'for-hire' : ''}`}>
            {job.listingType}
          </strong>
          {job.posted} · {job.location}
        </p>
        <h1>{job.title}</h1>
        <p className="company">
          posted by <Link href={ownerPath}>{job.company}</Link>
        </p>
        <dl>
          <div>
            <dt>compensation</dt>
            <dd>{job.compensation}</dd>
          </div>
          <div>
            <dt>location</dt>
            <dd>{job.location}</dd>
          </div>
        </dl>
        <section>
          <h2>about this job</h2>
          <p>{job.description}</p>
        </section>
        <div className="tags large-tags">
          {job.tags.map((tag) => (
            <Link key={tag} href={`/jobs?tag=${encodeURIComponent(tag)}`}>
              {tag}
            </Link>
          ))}
        </div>
        <button className="contact-button">
          {job.listingType === 'hiring'
            ? 'reply to this opportunity'
            : `contact ${job.company.split(' ')[0].toLowerCase()}`}
        </button>
      </div>
    </main>
  )
}

function OrganizationProfile() {
  const { organizationId } = useParams()
  const organization = organizations.find((item) => item.id === organizationId)
  if (!organization) return <NotFound />
  const openJobs = jobs.filter((job) => job.organizationId === organization.id)

  return (
    <main className="detail-page">
      <div className="breadcrumbs">
        <Link href="/">home</Link> › <Link href="/jobs">jobs</Link> › {organization.name}
      </div>
      <div className="detail-card organization-card">
        <div className="organization-heading">
          <img
            className="organization-profile-photo"
            src={organization.photo}
            alt={`${organization.name} profile`}
          />
          <div>
            <p className="eyebrow">organization profile</p>
            <h1>{organization.name}</h1>
            <p>
              {organization.type} · {organization.city}
            </p>
          </div>
        </div>
        <section>
          <h2>about</h2>
          <p>{organization.about}</p>
          <a href={`https://${organization.website}`}>{organization.website}</a>
        </section>
        <section>
          <h2>tags</h2>
          <p className="help-text">Select a tag to find similar organizations.</p>
          <div className="tags large-tags">
            {organization.tags.map((tag) => (
              <Link key={tag} href={`/organizations?tag=${encodeURIComponent(tag)}`}>
                {tag}
              </Link>
            ))}
          </div>
        </section>
        <section>
          <h2>open postings ({openJobs.length})</h2>
          {openJobs.length ? (
            openJobs.map((job) => <JobRow key={job.id} job={job} />)
          ) : (
            <p>No open postings right now.</p>
          )}
        </section>
      </div>
    </main>
  )
}

function NotFound() {
  return (
    <main className="not-found">
      <h1>404</h1>
      <p>That page was not found.</p>
      <Link href="/">return to search</Link>
    </main>
  )
}

function RouteView() {
  const pathname = usePathname()
  if (pathname === '/') return <HomePage />
  if (pathname === '/creators') return <ResultsPage kind="creators" />
  if (pathname.startsWith('/creators/')) return <CreatorProfile />
  if (pathname === '/jobs') return <ResultsPage kind="jobs" />
  if (pathname.startsWith('/jobs/')) return <JobDetail />
  if (pathname === '/organizations') return <OrganizationResultsPage />
  if (pathname.startsWith('/organizations/')) return <OrganizationProfile />
  if (pathname === '/search') return <CombinedSearchPage />
  return <NotFound />
}

function Outlet() {
  return <RouteView />
}

export default function LegacySite({
  registeredProfiles = [],
}: {
  registeredProfiles?: RegisteredProfile[]
}) {
  return (
    <RegisteredProfilesContext.Provider value={registeredProfiles}>
      <SiteLayout />
    </RegisteredProfilesContext.Provider>
  )
}
