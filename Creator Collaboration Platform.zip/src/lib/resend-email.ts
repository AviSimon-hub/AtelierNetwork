import type { EmailAdapter, SendEmailOptions } from 'payload'

const RESEND_ENDPOINT = 'https://api.resend.com/emails'
const DEFAULT_FROM = 'accounts@example.invalid'

function addressValues(value: SendEmailOptions['to']): string[] {
  if (!value) return []
  const values = Array.isArray(value) ? value : [value]

  return values.flatMap((entry) => {
    if (typeof entry === 'string') return [entry]
    if (entry && typeof entry === 'object' && 'address' in entry) return [String(entry.address)]
    return []
  })
}

function configuredSender() {
  return process.env.RESEND_FROM_EMAIL?.trim() || DEFAULT_FROM
}

function senderParts(sender: string) {
  const formatted = sender.match(/^\s*"?([^"<]+?)"?\s*<([^>]+)>\s*$/)
  return formatted
    ? { address: formatted[2], name: formatted[1].trim() }
    : { address: sender, name: 'Atelier Network' }
}

export const resendEmailAdapter: EmailAdapter = () => {
  const sender = configuredSender()
  const { address, name } = senderParts(sender)

  return {
    name: 'resend',
    defaultFromAddress: address,
    defaultFromName: name,
    async sendEmail(message) {
      const apiKey = process.env.RESEND_API_KEY
      const from = process.env.RESEND_FROM_EMAIL?.trim()
      if (!apiKey || !from) {
        throw new Error('Password reset email is not configured.')
      }

      const to = addressValues(message.to)
      if (!to.length || !message.subject) {
        throw new Error('Password reset email is missing a recipient or subject.')
      }

      const response = await fetch(RESEND_ENDPOINT, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from,
          to,
          subject: message.subject,
          html: typeof message.html === 'string' ? message.html : undefined,
          text: typeof message.text === 'string' ? message.text : undefined,
        }),
      })

      if (!response.ok) {
        throw new Error(`Resend rejected the password reset email (${response.status}).`)
      }

      return response.json()
    },
  }
}
