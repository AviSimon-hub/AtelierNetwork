import 'server-only'

import config from '@payload-config'
import { cookies } from 'next/headers'
import { getPayload } from 'payload'
import type { User } from '@/payload-types'

const SESSION_COOKIE = 'app-session'
const APP_USER_COLLECTION = 'users'

export type AppUser = User

export function createAppAuth(collection: 'users') {
  async function setSessionToken(token: string) {
    const payload = await getPayload({ config })
    const authHeaders = new Headers({ Authorization: `JWT ${token}` })
    const { user } = await payload.auth({ headers: authHeaders })
    if (!user || user.collection !== collection) throw new Error('Invalid app session')

    ;(await cookies()).set(SESSION_COOKIE, token, {
      httpOnly: true,
      maxAge: 60 * 60 * 24 * 7,
      path: '/',
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
    })
  }

  return {
    async currentUser(): Promise<AppUser | null> {
      const token = (await cookies()).get(SESSION_COOKIE)?.value
      if (!token) return null

      const payload = await getPayload({ config })
      const authHeaders = new Headers({ Authorization: `JWT ${token}` })
      const { user } = await payload.auth({ headers: authHeaders })
      if (!user || user.collection !== collection) return null
      return user as AppUser
    },

    async login(email: string, password: string) {
      const payload = await getPayload({ config })
      const result = await payload.login({
        collection,
        data: { email, password },
        overrideAccess: false,
      })
      if (!result.token || !result.user || result.user.collection !== collection) {
        throw new Error('Login failed')
      }

      await setSessionToken(result.token)

      return result.user as AppUser
    },

    setSessionToken,

    async logout() {
      ;(await cookies()).delete(SESSION_COOKIE)
    },
  }
}

export const appAuth = createAppAuth(APP_USER_COLLECTION)
