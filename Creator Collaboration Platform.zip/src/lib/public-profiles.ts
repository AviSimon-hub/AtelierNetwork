import 'server-only'

import config from '@payload-config'
import { getPayload } from 'payload'

export type RegisteredProfile = {
  id: string
  name: string
  role: 'creator' | 'organization'
  location: string
  description: string
  tags: string[]
  profileImageURL: string
  availableForWork: boolean
  noticeTitle: string
  noticeBody: string
}

export async function getRegisteredProfiles(): Promise<RegisteredProfile[]> {
  const payload = await getPayload({ config })
  const result = await payload.find({
    collection: 'users',
    depth: 1,
    limit: 100,
    overrideAccess: false,
    sort: '-createdAt',
    select: {
      name: true,
      role: true,
      location: true,
      description: true,
      tags: true,
      profileImage: true,
      availableForWork: true,
      noticeTitle: true,
      noticeBody: true,
    },
  })

  return result.docs.map((profile) => ({
    id: String(profile.id),
    name: profile.name,
    role: profile.role,
    location: profile.location ?? '',
    description: profile.description ?? '',
    tags: (profile.tags ?? []).map((item) => item.tag),
    availableForWork: profile.role === 'creator' && Boolean(profile.availableForWork),
    profileImageURL:
      typeof profile.profileImage === 'object' && profile.profileImage?.url
        ? profile.profileImage.url
        : '',
    noticeTitle: profile.noticeTitle ?? '',
    noticeBody: profile.noticeBody ?? '',
  }))
}
