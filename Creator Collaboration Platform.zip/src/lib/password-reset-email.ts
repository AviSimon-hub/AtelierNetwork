function escapeHtml(value: string) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;')
}

export function passwordResetURL(token: string) {
  const siteURL = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'
  const url = new URL('/reset-password', siteURL)
  url.searchParams.set('token', token)
  return url.toString()
}

export function passwordResetEmailHTML(token?: string) {
  if (!token) return ''
  const resetURL = escapeHtml(passwordResetURL(token))

  return `
    <div style="background:#f4f4f4;padding:32px 16px;font-family:Arial,Helvetica,sans-serif;color:#252525">
      <div style="max-width:560px;margin:0 auto;background:#ffffff;border-top:8px solid #7b4ab5;padding:32px">
        <p style="margin:0 0 8px;color:#0078b8;font-size:12px;font-weight:700;letter-spacing:.12em;text-transform:uppercase">Atelier Network</p>
        <h1 style="margin:0 0 16px;font-size:28px;font-weight:400">Reset your password</h1>
        <p style="margin:0 0 24px;line-height:1.6;color:#44565b">We received a request to reset your Atelier Network password. This link expires in one hour and can only be used once.</p>
        <a href="${resetURL}" style="display:inline-block;background:#f25022;color:#ffffff;padding:14px 22px;font-size:13px;font-weight:700;letter-spacing:.06em;text-decoration:none;text-transform:uppercase">Choose a new password</a>
        <p style="margin:24px 0 0;font-size:12px;line-height:1.6;color:#657477">If you did not request this change, you can safely ignore this email. Your password will stay the same.</p>
      </div>
    </div>
  `
}
