import config from '@payload-config'
import { getPayload } from 'payload'
import AccountClient from './AccountClient'
import SiteHeader from '@/components/SiteHeader'
import { appAuth, type AppUser } from '@/lib/app-auth'

export default async function AccountPage() {
  const sessionUser = await appAuth.currentUser()
  if (!sessionUser) {
    return (
      <>
        <SiteHeader active="account" />
        <AccountClient jobs={[]} messages={[]} user={null} />
      </>
    )
  }

  const payload = await getPayload({ config })
  const [account, jobsResult, messagesResult] = await Promise.all([
    payload.findByID({
      collection: 'users',
      id: sessionUser.id,
      depth: 1,
      overrideAccess: false,
      user: sessionUser,
    }),
    payload.find({
      collection: 'jobs',
      depth: 0,
      limit: 100,
      overrideAccess: false,
      sort: '-createdAt',
      user: sessionUser,
      where: { owner: { equals: sessionUser.id } },
    }),
    payload.find({
      collection: 'messages',
      depth: 1,
      limit: 100,
      overrideAccess: false,
      sort: '-createdAt',
      user: sessionUser,
    }),
  ])

  return (
    <>
      <SiteHeader active="account" />
      <AccountClient
        jobs={jobsResult.docs}
        messages={messagesResult.docs}
        user={account as AppUser}
      />
    </>
  )
}
