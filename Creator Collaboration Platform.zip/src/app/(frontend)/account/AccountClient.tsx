'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useActionState, useEffect, useRef, useState, useTransition, type DragEvent } from 'react'
import type { AppUser } from '@/lib/app-auth'
import {
  createJobAction,
  deleteJobAction,
  loginAction,
  logoutAction,
  removePortfolioAction,
  signupAction,
  updateJobAction,
  updateNoticeBoardAction,
  updatePasswordAction,
  updateProfileAction,
  uploadPortfolioAction,
  uploadProfileImageAction,
  type ActionState,
} from './actions'

const emptyState: ActionState = { ok: false, message: '' }

type JobView = {
  id: string
  title: string
  slug: string
  listingType: 'hiring' | 'for-hire'
  status: 'published' | 'draft'
  location: string
  compensation: string
  description: string
  tags?: { tag: string; id?: string | null }[] | null
  createdAt?: string
}

type MessageView = {
  id: number | string
  subject: string
  body: string
  createdAt?: string
  sender?: { id: number | string; name?: string | null } | number | string
  recipient?: { id: number | string; name?: string | null } | number | string
}

function Feedback({ state }: { state: ActionState }) {
  if (!state.message) return null
  return (
    <p
      className={`mt-4 border-l-4 px-4 py-3 text-sm ${
        state.ok
          ? 'border-[#7fba00] bg-[#eef7dd] text-[#365300]'
          : 'border-[#f25022] bg-[#fff0eb] text-[#8b270b]'
      }`}
      role="status"
    >
      {state.message}
    </p>
  )
}

function PasswordField({
  autoComplete,
  label,
  minLength,
  name,
}: {
  autoComplete: 'current-password' | 'new-password'
  label: string
  minLength?: number
  name: string
}) {
  const [visible, setVisible] = useState(false)

  return (
    <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
      {label}
      <span className="relative block">
        <input
          className="account-input pr-12"
          name={name}
          type={visible ? 'text' : 'password'}
          minLength={minLength}
          autoComplete={autoComplete}
          required
        />
        <button
          className="absolute inset-y-0 right-0 grid w-12 place-items-center text-[#53666b] hover:bg-[#e9f0f2] hover:text-[#0078b8]"
          onClick={() => setVisible((current) => !current)}
          type="button"
          aria-label={visible ? `Hide ${label.toLowerCase()}` : `Show ${label.toLowerCase()}`}
          title={visible ? 'Hide password' : 'Show password'}
        >
          {visible ? (
            <svg aria-hidden="true" viewBox="0 0 24 24" className="h-5 w-5" fill="none">
              <path
                d="M3 3l18 18M10.7 10.7a2 2 0 002.6 2.6M9.9 4.3A10.6 10.6 0 0112 4c5.4 0 9 5.3 9 5.3a15.6 15.6 0 01-2.3 2.8M6.2 6.2C4.2 7.6 3 9.3 3 9.3s3.6 5.4 9 5.4c1 0 2-.2 2.9-.5"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          ) : (
            <svg aria-hidden="true" viewBox="0 0 24 24" className="h-5 w-5" fill="none">
              <path
                d="M3 12s3.6-5.3 9-5.3S21 12 21 12s-3.6 5.3-9 5.3S3 12 3 12z"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinejoin="round"
              />
              <circle cx="12" cy="12" r="2.5" stroke="currentColor" strokeWidth="1.8" />
            </svg>
          )}
        </button>
      </span>
    </label>
  )
}

function DropFileInput({
  accept,
  help,
  name,
  title,
}: {
  accept: string
  help: string
  name: string
  title: string
}) {
  const [fileName, setFileName] = useState('')
  const [dragging, setDragging] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const useFiles = (files: FileList | null) => {
    const file = files?.[0]
    if (!file) return

    if (inputRef.current) {
      const transfer = new DataTransfer()
      transfer.items.add(file)
      inputRef.current.files = transfer.files
    }
    setFileName(file.name)
  }

  const drop = (event: DragEvent<HTMLLabelElement>) => {
    event.preventDefault()
    setDragging(false)
    useFiles(event.dataTransfer.files)
  }

  return (
    <label
      className={`group grid min-h-32 cursor-pointer place-items-center border-2 border-dashed p-5 text-center transition ${
        dragging
          ? 'border-[#00a4ef] bg-[#dff2f8] shadow-[inset_0_0_0_3px_white]'
          : 'border-[#8fa5ac] bg-[#f5f8f8] hover:border-[#00a4ef] hover:bg-[#e8f6fb]'
      }`}
      onDragEnter={(event) => {
        event.preventDefault()
        setDragging(true)
      }}
      onDragLeave={() => setDragging(false)}
      onDragOver={(event) => {
        event.preventDefault()
        event.dataTransfer.dropEffect = 'copy'
        setDragging(true)
      }}
      onDrop={drop}
    >
      <span>
        <svg
          aria-hidden="true"
          className="mx-auto mb-3 h-8 w-8 text-[#0078b8]"
          fill="none"
          viewBox="0 0 24 24"
        >
          <path
            d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M5 14v5h14v-5"
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.8"
          />
        </svg>
        <span className="block text-sm font-semibold normal-case tracking-normal text-[#0078b8]">
          {dragging ? 'Drop file here' : fileName || title}
        </span>
        <span className="mt-1 block text-[11px] font-normal normal-case tracking-normal text-[#657477]">
          {fileName ? 'Click or drop another file to replace it' : help}
        </span>
      </span>
      <input
        className="sr-only"
        ref={inputRef}
        name={name}
        type="file"
        accept={accept}
        onChange={(event) => useFiles(event.target.files)}
        required
      />
    </label>
  )
}

function AuthPanel() {
  const router = useRouter()
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [loginState, loginForm, loginPending] = useActionState(loginAction, emptyState)
  const [signupState, signupForm, signupPending] = useActionState(signupAction, emptyState)

  useEffect(() => {
    if (loginState.ok || signupState.ok) router.refresh()
  }, [loginState.ok, router, signupState.ok])

  return (
    <main className="mx-auto w-[min(1160px,calc(100%-40px))] py-12 md:py-20">
      <div className="grid overflow-hidden bg-white shadow-[14px_14px_0_#00a4ef] md:grid-cols-[0.82fr_1.18fr]">
        <section className="bg-[#252525] p-8 text-white md:p-12">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.18em] text-[#7fba00]">
            Member access
          </p>
          <h1 className="text-4xl font-extralight leading-tight md:text-5xl">
            Your creative work has a home here.
          </h1>
          <p className="mt-6 max-w-md text-sm leading-6 text-[#cbd7da]">
            Sign in to update your public profile, publish opportunities, and keep up with
            conversations across Atelier Network.
          </p>
          <div className="mt-10 grid grid-cols-3 gap-2" aria-hidden="true">
            <span className="h-2 bg-[#00a4ef]" />
            <span className="h-2 bg-[#7fba00]" />
            <span className="h-2 bg-[#f25022]" />
          </div>
        </section>

        <section className="border-t-[10px] border-[#7b4ab5] p-7 md:p-12">
          <div className="mb-8 flex border-b border-[#d9e3e5]">
            <button
              className={`px-5 py-3 text-sm font-semibold ${
                mode === 'login' ? 'bg-[#00a4ef] text-white' : 'text-[#0078b8]'
              }`}
              onClick={() => setMode('login')}
              type="button"
            >
              Existing user
            </button>
            <button
              className={`px-5 py-3 text-sm font-semibold ${
                mode === 'signup' ? 'bg-[#7fba00] text-white' : 'text-[#0078b8]'
              }`}
              onClick={() => setMode('signup')}
              type="button"
            >
              Create account
            </button>
          </div>

          {mode === 'login' ? (
            <form action={loginForm} className="grid gap-5">
              <div>
                <h2 className="text-3xl font-light text-[#252525]">Welcome back</h2>
                <p className="mt-1 text-sm text-[#657477]">Log in with your member credentials.</p>
              </div>
              <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
                Email
                <input
                  className="h-12 border-2 border-[#b7c4c8] bg-white px-3 text-base font-normal normal-case tracking-normal outline-none focus:border-[#00a4ef]"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                />
              </label>
              <PasswordField autoComplete="current-password" label="Password" name="password" />
              <div className="-mt-2 text-right">
                <Link
                  className="text-sm font-semibold text-[#0078b8] hover:underline"
                  href="/forgot-password"
                >
                  Forgot password?
                </Link>
              </div>
              <button
                className="mt-2 h-12 bg-[#f25022] px-6 text-sm font-semibold uppercase tracking-wider text-white hover:bg-[#d83f14] disabled:bg-[#aeb8bb]"
                disabled={loginPending}
                type="submit"
              >
                {loginPending ? 'Logging in…' : 'Log in'}
              </button>
              <Feedback state={loginState} />
            </form>
          ) : (
            <form action={signupForm} className="grid gap-5">
              <div>
                <h2 className="text-3xl font-light text-[#252525]">Join Atelier</h2>
                <p className="mt-1 text-sm text-[#657477]">
                  Choose the account type that best represents you.
                </p>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {(['creator', 'organization'] as const).map((role) => (
                  <label
                    className="flex cursor-pointer items-start gap-3 border-2 border-[#d3dfe2] p-4 has-[:checked]:border-[#7fba00] has-[:checked]:bg-[#f0f8e4]"
                    key={role}
                  >
                    <input
                      className="mt-1 accent-[#7fba00]"
                      name="role"
                      type="radio"
                      value={role}
                      required
                    />
                    <span>
                      <strong className="block capitalize">{role}</strong>
                      <small className="mt-1 block leading-5 text-[#657477]">
                        {role === 'creator'
                          ? 'Show your practice and availability.'
                          : 'Post roles and represent your team.'}
                      </small>
                    </span>
                  </label>
                ))}
              </div>
              <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
                Public name
                <input
                  className="h-12 border-2 border-[#b7c4c8] px-3 text-base font-normal normal-case tracking-normal outline-none focus:border-[#00a4ef]"
                  name="name"
                  maxLength={100}
                  required
                />
              </label>
              <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
                Email
                <input
                  className="h-12 border-2 border-[#b7c4c8] px-3 text-base font-normal normal-case tracking-normal outline-none focus:border-[#00a4ef]"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                />
              </label>
              <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
                Phone number
                <input
                  className="h-12 border-2 border-[#b7c4c8] px-3 text-base font-normal normal-case tracking-normal outline-none focus:border-[#00a4ef]"
                  name="phone"
                  type="tel"
                  autoComplete="tel"
                  placeholder="+1 212 555 0100"
                  required
                />
                <small className="font-normal normal-case tracking-normal text-[#657477]">
                  Include your country code for verification.
                </small>
              </label>
              <div>
                <PasswordField
                  autoComplete="new-password"
                  label="Password"
                  minLength={8}
                  name="password"
                />
                <small className="font-normal normal-case tracking-normal text-[#657477]">
                  8 characters minimum
                </small>
              </div>
              <button
                className="mt-2 h-12 bg-[#7fba00] px-6 text-sm font-semibold uppercase tracking-wider text-white hover:bg-[#6ca000] disabled:bg-[#aeb8bb]"
                disabled={signupPending}
                type="submit"
              >
                {signupPending ? 'Creating account…' : 'Create account'}
              </button>
              <Feedback state={signupState} />
            </form>
          )}
        </section>
      </div>
    </main>
  )
}

function ProfilePanel({ user }: { user: AppUser }) {
  const router = useRouter()
  const [profileState, profileForm, profilePending] = useActionState(
    updateProfileAction,
    emptyState,
  )
  const [uploadState, uploadForm, uploadPending] = useActionState(uploadPortfolioAction, emptyState)
  const [imageState, imageForm, imagePending] = useActionState(uploadProfileImageAction, emptyState)
  const [noticeState, noticeForm, noticePending] = useActionState(
    updateNoticeBoardAction,
    emptyState,
  )
  const [removing, startRemoving] = useTransition()

  useEffect(() => {
    if (profileState.ok || uploadState.ok || imageState.ok || noticeState.ok) router.refresh()
  }, [imageState.ok, noticeState.ok, profileState.ok, router, uploadState.ok])

  const media = (user.portfolio ?? []).filter(
    (item): item is Exclude<typeof item, number | string> => typeof item === 'object',
  )

  return (
    <div className="grid gap-8">
      <div>
        <h2 className="text-3xl font-light">Edit profile</h2>
        <p className="mt-1 text-sm text-[#657477]">
          These details shape your public {user.role} profile.
        </p>
      </div>

      <section>
        <h3 className="border-l-8 border-[#ffb900] bg-[#fff3bf] px-4 py-3 text-xl font-light">
          Notice board
        </h3>
        <p className="mt-3 text-sm text-[#657477]">
          Share a current announcement, event, availability update, or collaboration request.
        </p>
        <form action={noticeForm} className="mt-5 grid gap-4 bg-[#fff9df] p-5">
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#6c5b25]">
            Headline
            <input
              className="account-input"
              defaultValue={user.noticeTitle ?? ''}
              maxLength={140}
              name="noticeTitle"
              placeholder="What would you like people to know?"
            />
          </label>
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#6c5b25]">
            Message
            <textarea
              className="min-h-28 border-2 border-[#d4bd63] bg-white p-3 text-sm font-normal normal-case leading-6 tracking-normal outline-none focus:border-[#ffb900]"
              defaultValue={user.noticeBody ?? ''}
              maxLength={600}
              name="noticeBody"
              placeholder="Add the details here."
            />
          </label>
          <div className="flex flex-wrap items-center gap-3">
            <button
              className="min-h-11 bg-[#ffb900] px-5 py-3 text-xs font-semibold uppercase tracking-wider text-[#382800] hover:bg-[#e4a600] disabled:bg-[#c8c0a1]"
              disabled={noticePending}
              type="submit"
            >
              {noticePending ? 'Saving…' : 'Save notice'}
            </button>
            <span className="text-xs text-[#6c5b25]">
              Clear both fields and save to remove the notice.
            </span>
          </div>
        </form>
        <Feedback state={noticeState} />
      </section>

      <section>
        <h3 className="border-l-8 border-[#00a4ef] bg-[#e9f0f2] px-4 py-3 text-xl font-light">
          Profile image
        </h3>
        <div className="mt-5 grid items-center gap-5 sm:grid-cols-[128px_1fr]">
          <div className="grid h-32 w-32 place-items-center overflow-hidden bg-[#dce6e8] text-4xl font-light text-[#53666b]">
            {user.profileImage && typeof user.profileImage === 'object' && user.profileImage.url ? (
              <Image
                className="h-full w-full object-cover"
                src={user.profileImage.url}
                alt={user.profileImage.alt || `${user.name} profile image`}
                width={user.profileImage.width || 320}
                height={user.profileImage.height || 320}
              />
            ) : (
              user.name.slice(0, 1).toUpperCase()
            )}
          </div>
          <form action={imageForm} className="grid gap-3">
            <DropFileInput
              accept="image/*"
              help="Click to browse or drag and drop an image"
              name="profileImage"
              title="Choose profile image"
            />
            <button
              className="account-secondary justify-self-start"
              disabled={imagePending}
              type="submit"
            >
              {imagePending ? 'Uploading…' : 'Update profile image'}
            </button>
          </form>
        </div>
        <Feedback state={imageState} />
      </section>

      <form action={profileForm} className="grid gap-5 border-t border-[#d9e3e5] pt-8">
        <div className="grid gap-5 sm:grid-cols-2">
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
            Name
            <input className="account-input" name="name" defaultValue={user.name ?? ''} required />
          </label>
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
            Location
            <input
              className="account-input"
              name="location"
              defaultValue={user.location ?? ''}
              placeholder="City, country or remote"
            />
          </label>
        </div>
        {user.role === 'creator' ? (
          <label className="flex cursor-pointer items-start gap-4 border-l-4 border-[#7fba00] bg-[#f0f8e4] p-4">
            <input
              className="mt-1 h-5 w-5 shrink-0 accent-[#7fba00]"
              defaultChecked={user.availableForWork ?? false}
              name="availableForWork"
              type="checkbox"
            />
            <span>
              <strong className="block text-sm text-[#365300]">Available for work</strong>
              <small className="mt-1 block leading-5 text-[#53666b]">
                Show an availability badge on your public profile and in the creators directory.
              </small>
            </span>
          </label>
        ) : null}
        <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
          Tags
          <input
            className="account-input"
            name="tags"
            defaultValue={(user.tags ?? [])
              .map((item) => item.tag)
              .filter(Boolean)
              .join(', ')}
            placeholder="illustration, murals, game art"
          />
          <small className="font-normal normal-case tracking-normal text-[#657477]">
            Separate tags with commas.
          </small>
        </label>
        <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
          Description
          <textarea
            className="min-h-36 border-2 border-[#b7c4c8] p-3 text-sm font-normal normal-case leading-6 tracking-normal outline-none focus:border-[#00a4ef]"
            name="description"
            defaultValue={user.description ?? ''}
            maxLength={2000}
          />
        </label>
        <div>
          <button className="account-primary" disabled={profilePending} type="submit">
            {profilePending ? 'Saving…' : 'Save profile'}
          </button>
          <Feedback state={profileState} />
        </div>
      </form>

      <section className="border-t border-[#d9e3e5] pt-8">
        <h3 className="border-l-8 border-[#7fba00] bg-[#e9f0f2] px-4 py-3 text-xl font-light">
          Portfolio media
        </h3>
        <p className="mt-3 text-sm text-[#657477]">
          Add images, video reels, or audio work. Files may be up to 25 MB.
        </p>
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          {media.map((item) => (
            <figure className="group relative overflow-hidden bg-[#e9f0f2]" key={String(item.id)}>
              {item.mimeType?.startsWith('image/') && item.url ? (
                <Image
                  className="h-48 w-full object-cover"
                  src={item.url}
                  alt={item.alt || item.filename || 'Portfolio image'}
                  width={item.width || 640}
                  height={item.height || 480}
                />
              ) : item.mimeType?.startsWith('video/') && item.url ? (
                <video className="h-48 w-full bg-black object-contain" controls src={item.url} />
              ) : item.url ? (
                <div className="flex h-32 items-center bg-[#dff2f8] px-5">
                  <audio className="w-full" controls src={item.url} />
                </div>
              ) : null}
              <figcaption className="flex items-center justify-between gap-3 p-3 text-xs">
                <span className="truncate">{item.alt || item.filename || 'Portfolio item'}</span>
                <button
                  className="font-semibold text-[#b3310d] hover:underline disabled:opacity-50"
                  disabled={removing}
                  onClick={() =>
                    startRemoving(async () => {
                      const result = await removePortfolioAction(String(item.id))
                      if (result.ok) router.refresh()
                    })
                  }
                  type="button"
                >
                  remove
                </button>
              </figcaption>
            </figure>
          ))}
          <form
            action={uploadForm}
            className="grid min-h-48 content-center gap-3 border-2 border-dashed border-[#8fa5ac] bg-[#f5f8f8] p-5"
          >
            <DropFileInput
              accept="image/*,video/*,audio/*"
              help="Click to browse or drag and drop image, video, or audio"
              name="media"
              title="Choose portfolio file"
            />
            <input className="account-input" name="alt" placeholder="Title or image description" />
            <button className="account-secondary" disabled={uploadPending} type="submit">
              {uploadPending ? 'Uploading…' : 'Add to portfolio'}
            </button>
          </form>
        </div>
        <Feedback state={uploadState} />
      </section>
    </div>
  )
}

function JobsPanel({ jobs }: { jobs: JobView[] }) {
  const router = useRouter()
  const [state, formAction, pending] = useActionState(createJobAction, emptyState)
  useEffect(() => {
    if (state.ok) router.refresh()
  }, [router, state.ok])

  return (
    <div className="grid gap-8">
      <div>
        <h2 className="text-3xl font-light">Manage jobs</h2>
        <p className="mt-1 text-sm text-[#657477]">
          Publish an opportunity now or save it as a private draft.
        </p>
      </div>
      <form action={formAction} className="grid gap-5 bg-[#f2f6f7] p-5 md:p-7">
        <div className="grid gap-5 sm:grid-cols-2">
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
            Listing type
            <select className="account-input" name="listingType" required>
              <option value="hiring">Hiring</option>
              <option value="for-hire">For Hire</option>
            </select>
          </label>
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
            Visibility
            <select className="account-input" name="status" required>
              <option value="published">Publish now</option>
              <option value="draft">Save as draft</option>
            </select>
          </label>
        </div>
        <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
          Title
          <input className="account-input" name="title" maxLength={140} required />
        </label>
        <div className="grid gap-5 sm:grid-cols-2">
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
            Location
            <input className="account-input" name="location" required />
          </label>
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
            Compensation
            <input className="account-input" name="compensation" required />
          </label>
        </div>
        <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
          Tags
          <input className="account-input" name="tags" placeholder="music, freelance, remote" />
        </label>
        <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
          Description
          <textarea
            className="min-h-36 border-2 border-[#b7c4c8] bg-white p-3 text-sm font-normal normal-case leading-6 tracking-normal outline-none focus:border-[#00a4ef]"
            name="description"
            maxLength={5000}
            required
          />
        </label>
        <button className="account-primary justify-self-start" disabled={pending} type="submit">
          {pending ? 'Saving…' : 'Save listing'}
        </button>
        <Feedback state={state} />
      </form>

      <section>
        <h3 className="border-l-8 border-[#f25022] bg-[#e9f0f2] px-4 py-3 text-xl font-light">
          Your listings ({jobs.length})
        </h3>
        <div className="mt-3 divide-y divide-[#d9e3e5] border-y border-[#d9e3e5]">
          {jobs.length ? (
            jobs.map((job) => <JobListingEditor job={job} key={job.id} />)
          ) : (
            <p className="py-8 text-sm text-[#657477]">You have not created any jobs yet.</p>
          )}
        </div>
      </section>
    </div>
  )
}

function JobListingEditor({ job }: { job: JobView }) {
  const router = useRouter()
  const [editing, setEditing] = useState(false)
  const [confirmingRemoval, setConfirmingRemoval] = useState(false)
  const [removeState, setRemoveState] = useState<ActionState>(emptyState)
  const [removing, startRemoving] = useTransition()
  const [updateState, updateForm, updating] = useActionState(updateJobAction, emptyState)

  useEffect(() => {
    if (updateState.ok) {
      setEditing(false)
      router.refresh()
    }
  }, [router, updateState.ok])

  const remove = () => {
    startRemoving(async () => {
      const result = await deleteJobAction(job.id)
      setRemoveState(result)
      if (result.ok) router.refresh()
    })
  }

  return (
    <article className="grid gap-4 py-5">
      <div className="grid gap-3 sm:grid-cols-[1fr_auto] sm:items-center">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <Link className="text-lg text-[#0078b8]" href={`/jobs/${job.slug}`}>
              {job.title}
            </Link>
            <span
              className={`px-2 py-1 text-[10px] font-semibold uppercase ${
                job.status === 'published'
                  ? 'bg-[#7fba00] text-white'
                  : 'bg-[#dce5e7] text-[#53666b]'
              }`}
            >
              {job.status}
            </span>
          </div>
          <p className="mt-1 text-xs text-[#657477]">
            {job.listingType === 'for-hire' ? 'For Hire' : 'Hiring'} · {job.location}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            className="border-2 border-[#0078b8] px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#0078b8] hover:bg-[#e8f6fb]"
            onClick={() => {
              setEditing((current) => !current)
              setConfirmingRemoval(false)
            }}
            type="button"
          >
            {editing ? 'Cancel edit' : 'Edit'}
          </button>
          <button
            className="border-2 border-[#b3310d] px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#b3310d] hover:bg-[#fff0eb]"
            onClick={() => {
              setConfirmingRemoval(true)
              setEditing(false)
              setRemoveState(emptyState)
            }}
            type="button"
          >
            Remove
          </button>
        </div>
      </div>

      {editing ? (
        <form
          action={updateForm}
          className="grid gap-5 border-l-4 border-[#00a4ef] bg-[#f2f6f7] p-5"
        >
          <input name="jobId" type="hidden" value={job.id} />
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
              Listing type
              <select
                className="account-input"
                defaultValue={job.listingType}
                name="listingType"
                required
              >
                <option value="hiring">Hiring</option>
                <option value="for-hire">For Hire</option>
              </select>
            </label>
            <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
              Visibility
              <select className="account-input" defaultValue={job.status} name="status" required>
                <option value="published">Published</option>
                <option value="draft">Draft</option>
              </select>
            </label>
          </div>
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
            Title
            <input
              className="account-input"
              defaultValue={job.title}
              maxLength={140}
              name="title"
              required
            />
          </label>
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
              Location
              <input
                className="account-input"
                defaultValue={job.location}
                maxLength={120}
                name="location"
                required
              />
            </label>
            <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
              Compensation
              <input
                className="account-input"
                defaultValue={job.compensation}
                maxLength={120}
                name="compensation"
                required
              />
            </label>
          </div>
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
            Tags
            <input
              className="account-input"
              defaultValue={job.tags?.map(({ tag }) => tag).join(', ') ?? ''}
              name="tags"
              placeholder="music, freelance, remote"
            />
          </label>
          <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
            Description
            <textarea
              className="min-h-36 border-2 border-[#b7c4c8] bg-white p-3 text-sm font-normal normal-case leading-6 tracking-normal outline-none focus:border-[#00a4ef]"
              defaultValue={job.description}
              maxLength={5000}
              name="description"
              required
            />
          </label>
          <div className="flex flex-wrap gap-3">
            <button className="account-primary" disabled={updating} type="submit">
              {updating ? 'Saving…' : 'Save changes'}
            </button>
            <button
              className="account-secondary"
              disabled={updating}
              onClick={() => setEditing(false)}
              type="button"
            >
              Cancel
            </button>
          </div>
          <Feedback state={updateState} />
        </form>
      ) : null}
      {!editing && updateState.message ? <Feedback state={updateState} /> : null}

      {confirmingRemoval ? (
        <div className="border-l-4 border-[#f25022] bg-[#fff0eb] p-5">
          <p className="font-semibold text-[#8b270b]">Remove “{job.title}” permanently?</p>
          <p className="mt-1 text-sm text-[#704235]">
            This cannot be undone and the public listing will no longer be available.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <button
              className="bg-[#b3310d] px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white hover:bg-[#8b270b] disabled:opacity-50"
              disabled={removing}
              onClick={remove}
              type="button"
            >
              {removing ? 'Removing…' : 'Yes, remove listing'}
            </button>
            <button
              className="border-2 border-[#657477] px-4 py-2 text-xs font-semibold uppercase tracking-wider text-[#44565b]"
              disabled={removing}
              onClick={() => setConfirmingRemoval(false)}
              type="button"
            >
              Keep listing
            </button>
          </div>
          <Feedback state={removeState} />
        </div>
      ) : null}
    </article>
  )
}

function MessagesPanel({ messages, userId }: { messages: MessageView[]; userId: string }) {
  return (
    <div>
      <h2 className="text-3xl font-light">Messages</h2>
      <p className="mt-1 text-sm text-[#657477]">Conversations connected to your Atelier work.</p>
      <div className="mt-7 divide-y divide-[#d9e3e5] border-y border-[#d9e3e5]">
        {messages.length ? (
          messages.map((message) => {
            const senderId = typeof message.sender === 'object' ? message.sender.id : message.sender
            const contact =
              String(senderId) === userId
                ? typeof message.recipient === 'object'
                  ? message.recipient.name
                  : 'Member'
                : typeof message.sender === 'object'
                  ? message.sender.name
                  : 'Member'
            return (
              <article className="grid gap-2 py-5" key={String(message.id)}>
                <div className="flex items-baseline justify-between gap-4">
                  <h3 className="font-semibold text-[#0078b8]">{message.subject}</h3>
                  <time className="text-[11px] text-[#657477]">
                    {message.createdAt ? new Date(message.createdAt).toLocaleDateString() : ''}
                  </time>
                </div>
                <p className="text-xs font-semibold uppercase tracking-wider text-[#53666b]">
                  {contact || 'Atelier member'}
                </p>
                <p className="line-clamp-2 text-sm leading-6 text-[#44565b]">{message.body}</p>
              </article>
            )
          })
        ) : (
          <div className="py-14 text-center">
            <p className="text-lg font-light">No messages yet</p>
            <p className="mt-2 text-sm text-[#657477]">
              Replies to your profiles and job listings will appear here.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

function SettingsPanel({ user }: { user: AppUser }) {
  const router = useRouter()
  const [passwordState, passwordForm, passwordPending] = useActionState(
    updatePasswordAction,
    emptyState,
  )
  const [loggingOut, startLogout] = useTransition()
  return (
    <div className="grid gap-8">
      <div>
        <h2 className="text-3xl font-light">Settings</h2>
        <p className="mt-1 text-sm text-[#657477]">Security and account information.</p>
      </div>
      <dl className="grid gap-px bg-[#d9e3e5] sm:grid-cols-2">
        <div className="bg-[#f5f8f8] p-5">
          <dt className="text-xs font-semibold uppercase tracking-wider text-[#657477]">Email</dt>
          <dd className="mt-2 text-sm">{user.email}</dd>
        </div>
        <div className="bg-[#f5f8f8] p-5">
          <dt className="text-xs font-semibold uppercase tracking-wider text-[#657477]">
            Account type
          </dt>
          <dd className="mt-2 text-sm capitalize">{user.role}</dd>
        </div>
      </dl>
      <form action={passwordForm} className="grid max-w-lg gap-4">
        <h3 className="border-l-8 border-[#7b4ab5] bg-[#e9f0f2] px-4 py-3 text-xl font-light">
          Change password
        </h3>
        <PasswordField
          autoComplete="current-password"
          label="Current password"
          name="currentPassword"
        />
        <PasswordField
          autoComplete="new-password"
          label="New password"
          minLength={8}
          name="newPassword"
        />
        <PasswordField
          autoComplete="new-password"
          label="Confirm new password"
          minLength={8}
          name="confirmPassword"
        />
        <p className="-mt-1 text-xs text-[#657477]">
          Your new password must be at least 8 characters.
        </p>
        <button
          className="account-secondary justify-self-start"
          disabled={passwordPending}
          type="submit"
        >
          {passwordPending ? 'Updating…' : 'Update password'}
        </button>
        <Feedback state={passwordState} />
      </form>
      <div className="border-t border-[#d9e3e5] pt-7">
        <button
          className="border-2 border-[#f25022] px-5 py-3 text-sm font-semibold text-[#b3310d] hover:bg-[#fff0eb]"
          disabled={loggingOut}
          onClick={() =>
            startLogout(async () => {
              await logoutAction()
              router.refresh()
            })
          }
          type="button"
        >
          {loggingOut ? 'Logging out…' : 'Log out'}
        </button>
      </div>
    </div>
  )
}

export default function AccountClient({
  user,
  jobs,
  messages,
}: {
  user: AppUser | null
  jobs: JobView[]
  messages: MessageView[]
}) {
  const [section, setSection] = useState<'profile' | 'jobs' | 'messages' | 'settings'>('profile')
  if (!user) return <AuthPanel />

  const nav = [
    ['profile', 'Edit Profile', '#00a4ef'],
    ['jobs', 'Manage Jobs', '#7fba00'],
    ['messages', 'Messages', '#f25022'],
    ['settings', 'Settings', '#7b4ab5'],
  ] as const

  return (
    <main className="mx-auto w-[min(1160px,calc(100%-24px))] py-8 md:py-12">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#657477]">
            My account
          </p>
          <h1 className="mt-1 text-4xl font-extralight">{user.name}</h1>
        </div>
        <div className="flex items-center gap-3">
          <Link
            className="text-sm font-semibold text-[#0078b8] hover:underline"
            href={`/profiles/${user.id}`}
          >
            view public profile
          </Link>
          <span className="bg-[#252525] px-3 py-2 text-xs font-semibold uppercase tracking-wider text-white">
            {user.role}
          </span>
        </div>
      </div>
      <div className="grid bg-white shadow-[10px_10px_0_rgba(0,164,239,0.18)] md:grid-cols-[220px_minmax(0,1fr)]">
        <aside className="bg-[#252525] p-3 md:min-h-[620px] md:p-0">
          <nav className="grid gap-1" aria-label="Account sections">
            {nav.map(([value, label, color]) => (
              <button
                className={`border-l-8 px-5 py-4 text-left text-sm transition ${
                  section === value
                    ? 'bg-white text-[#252525]'
                    : 'bg-transparent text-[#dce6e8] hover:bg-[#343434]'
                }`}
                key={value}
                onClick={() => setSection(value)}
                style={{ borderLeftColor: color }}
                type="button"
              >
                {label}
              </button>
            ))}
          </nav>
        </aside>
        <section className="min-w-0 border-t-[10px] border-[#00a4ef] p-6 md:p-10">
          {section === 'profile' && <ProfilePanel user={user} />}
          {section === 'jobs' && <JobsPanel jobs={jobs} />}
          {section === 'messages' && <MessagesPanel messages={messages} userId={String(user.id)} />}
          {section === 'settings' && <SettingsPanel user={user} />}
        </section>
      </div>
    </main>
  )
}
