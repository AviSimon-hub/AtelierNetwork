'use server'

import config from '@payload-config'
import { getPayload } from 'payload'
import { appAuth } from '@/lib/app-auth'

export type ActionState = {
  ok: boolean
  message: string
  fieldErrors?: Record<string, string>
}

const initialFailure = (message: string): ActionState => ({ ok: false, message })

function text(formData: FormData, key: string, max: number) {
  const value = formData.get(key)
  return typeof value === 'string' ? value.trim().slice(0, max) : ''
}

function tagsFrom(value: string) {
  return [
    ...new Set(
      value
        .split(',')
        .map((tag) => tag.trim().toLowerCase())
        .filter(Boolean),
    ),
  ]
    .slice(0, 20)
    .map((tag) => ({ tag: tag.slice(0, 40) }))
}

function messageFromError(error: unknown, fallback: string) {
  if (error instanceof Error && /email|password|login|credentials/i.test(error.message)) {
    return 'Check your email and password, then try again.'
  }
  return fallback
}

export async function signupAction(
  _previous: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const email = text(formData, 'email', 200).toLowerCase()
  const password = text(formData, 'password', 200)
  const name = text(formData, 'name', 100)
  const phone = text(formData, 'phone', 24)
  const role = text(formData, 'role', 20)
  const fieldErrors: Record<string, string> = {}

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) fieldErrors.email = 'Enter a valid email.'
  if (password.length < 8) fieldErrors.password = 'Use at least 8 characters.'
  if (!name) fieldErrors.name = 'Enter your public name.'
  if (!/^\+?[0-9][0-9 ()-]{7,22}$/.test(phone)) {
    fieldErrors.phone = 'Enter a valid phone number including country code.'
  }
  if (role !== 'creator' && role !== 'organization') {
    fieldErrors.role = 'Choose creator or organization.'
  }
  if (Object.keys(fieldErrors).length) {
    return { ok: false, message: 'Please correct the highlighted fields.', fieldErrors }
  }

  try {
    const payload = await getPayload({ config })
    await payload.create({
      collection: 'users',
      data: {
        email,
        name,
        password,
        phone,
        role: role as 'creator' | 'organization',
      },
      overrideAccess: false,
    })
    await appAuth.login(email, password)
    return { ok: true, message: 'Account created.' }
  } catch (error) {
    return initialFailure(messageFromError(error, 'An account with that email may already exist.'))
  }
}

export async function loginAction(
  _previous: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const email = text(formData, 'email', 200).toLowerCase()
  const password = text(formData, 'password', 200)
  if (!email || !password) return initialFailure('Enter your email and password.')

  try {
    await appAuth.login(email, password)
    return { ok: true, message: 'Logged in.' }
  } catch (error) {
    return initialFailure(messageFromError(error, 'Unable to log in.'))
  }
}

export async function logoutAction(): Promise<ActionState> {
  await appAuth.logout()
  return { ok: true, message: 'Logged out.' }
}

export async function updateProfileAction(
  _previous: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await appAuth.currentUser()
  if (!user) return initialFailure('Your session has expired. Log in again.')

  const name = text(formData, 'name', 100)
  if (!name) return initialFailure('Name is required.')

  const payload = await getPayload({ config })
  try {
    await payload.update({
      collection: 'users',
      id: user.id,
      data: {
        name,
        availableForWork: user.role === 'creator' && formData.get('availableForWork') === 'on',
        location: text(formData, 'location', 120),
        description: text(formData, 'description', 2000),
        tags: tagsFrom(text(formData, 'tags', 1000)),
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Profile saved.' }
  } catch {
    return initialFailure('The profile could not be saved.')
  }
}

export async function updateNoticeBoardAction(
  _previous: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await appAuth.currentUser()
  if (!user) return initialFailure('Your session has expired. Log in again.')

  const noticeTitle = text(formData, 'noticeTitle', 140)
  const noticeBody = text(formData, 'noticeBody', 600)
  if (!noticeTitle && noticeBody) return initialFailure('Add a headline for your notice.')
  if (noticeTitle && !noticeBody) return initialFailure('Add a message for your notice.')

  const payload = await getPayload({ config })
  try {
    await payload.update({
      collection: 'users',
      id: user.id,
      data: {
        noticeTitle: noticeTitle || null,
        noticeBody: noticeBody || null,
      },
      overrideAccess: false,
      user,
    })
    return {
      ok: true,
      message: noticeTitle ? 'Notice board updated.' : 'Notice board cleared.',
    }
  } catch {
    return initialFailure('The notice board could not be saved.')
  }
}

export async function uploadPortfolioAction(
  _previous: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await appAuth.currentUser()
  if (!user) return initialFailure('Your session has expired. Log in again.')

  const incoming = formData.get('media')
  if (!(incoming instanceof File) || incoming.size === 0) {
    return initialFailure('Choose an image, video, or audio file.')
  }
  if (incoming.size > 25 * 1024 * 1024) {
    return initialFailure('Files must be 25 MB or smaller.')
  }
  if (!/^(image|video|audio)\//.test(incoming.type)) {
    return initialFailure('That file type is not supported.')
  }

  const payload = await getPayload({ config })
  try {
    const account = await payload.findByID({
      collection: 'users',
      id: user.id,
      depth: 0,
      overrideAccess: false,
      user,
    })
    const existing = Array.isArray(account.portfolio)
      ? account.portfolio.map((item) => (typeof item === 'object' ? item.id : item))
      : []
    const bytes = Buffer.from(await incoming.arrayBuffer())
    const media = await payload.create({
      collection: 'media',
      data: { alt: text(formData, 'alt', 160) || incoming.name },
      file: {
        data: bytes,
        mimetype: incoming.type,
        name: incoming.name.slice(0, 180),
        size: incoming.size,
      },
      overrideAccess: false,
      user,
    })
    await payload.update({
      collection: 'users',
      id: user.id,
      data: { portfolio: [...existing, media.id] },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Portfolio item added.' }
  } catch {
    return initialFailure('The file could not be uploaded.')
  }
}

export async function uploadProfileImageAction(
  _previous: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await appAuth.currentUser()
  if (!user) return initialFailure('Your session has expired. Log in again.')

  const incoming = formData.get('profileImage')
  if (!(incoming instanceof File) || incoming.size === 0) {
    return initialFailure('Choose a profile image.')
  }
  if (incoming.size > 10 * 1024 * 1024) {
    return initialFailure('Profile images must be 10 MB or smaller.')
  }
  if (!incoming.type.startsWith('image/')) {
    return initialFailure('Profile images must be an image file.')
  }

  const payload = await getPayload({ config })
  try {
    const bytes = Buffer.from(await incoming.arrayBuffer())
    const media = await payload.create({
      collection: 'media',
      data: { alt: `${user.name} profile image` },
      file: {
        data: bytes,
        mimetype: incoming.type,
        name: incoming.name.slice(0, 180),
        size: incoming.size,
      },
      overrideAccess: false,
      user,
    })
    await payload.update({
      collection: 'users',
      id: user.id,
      data: { profileImage: media.id },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Profile image updated.' }
  } catch {
    return initialFailure('The profile image could not be uploaded.')
  }
}

export async function removePortfolioAction(mediaId: string): Promise<ActionState> {
  const user = await appAuth.currentUser()
  if (!user) return initialFailure('Your session has expired. Log in again.')

  const payload = await getPayload({ config })
  try {
    const account = await payload.findByID({
      collection: 'users',
      id: user.id,
      depth: 0,
      overrideAccess: false,
      user,
    })
    const next = (account.portfolio ?? [])
      .map((item) => (typeof item === 'object' ? item.id : item))
      .filter((id) => String(id) !== mediaId)
    await payload.update({
      collection: 'users',
      id: user.id,
      data: { portfolio: next },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Portfolio item removed.' }
  } catch {
    return initialFailure('The portfolio item could not be removed.')
  }
}

export async function createJobAction(
  _previous: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await appAuth.currentUser()
  if (!user) return initialFailure('Your session has expired. Log in again.')

  const title = text(formData, 'title', 140)
  const location = text(formData, 'location', 120)
  const compensation = text(formData, 'compensation', 120)
  const description = text(formData, 'description', 5000)
  const listingType = text(formData, 'listingType', 20)
  const status = text(formData, 'status', 20)
  if (!title || !location || !compensation || !description) {
    return initialFailure('Complete all required job fields.')
  }
  if (!['hiring', 'for-hire'].includes(listingType)) {
    return initialFailure('Choose a listing type.')
  }
  if (!['published', 'draft'].includes(status)) {
    return initialFailure('Choose published or draft.')
  }

  const slugBase = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 130)
  const payload = await getPayload({ config })
  try {
    await payload.create({
      collection: 'jobs',
      data: {
        compensation,
        description,
        listingType: listingType as 'hiring' | 'for-hire',
        location,
        posterName: user.name || user.email || 'Atelier member',
        slug: `${slugBase || 'opportunity'}-${crypto.randomUUID().slice(0, 8)}`,
        status: status as 'published' | 'draft',
        tags: tagsFrom(text(formData, 'tags', 1000)),
        title,
      },
      overrideAccess: false,
      user,
    })
    return {
      ok: true,
      message: status === 'published' ? 'Job published to the jobs page.' : 'Draft saved.',
    }
  } catch {
    return initialFailure('The job could not be saved.')
  }
}

export async function updateJobAction(
  _previous: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await appAuth.currentUser()
  if (!user) return initialFailure('Your session has expired. Log in again.')

  const jobId = text(formData, 'jobId', 100)
  const title = text(formData, 'title', 140)
  const location = text(formData, 'location', 120)
  const compensation = text(formData, 'compensation', 120)
  const description = text(formData, 'description', 5000)
  const listingType = text(formData, 'listingType', 20)
  const status = text(formData, 'status', 20)
  if (!jobId) return initialFailure('This job listing could not be identified.')
  if (!title || !location || !compensation || !description) {
    return initialFailure('Complete all required job fields.')
  }
  if (!['hiring', 'for-hire'].includes(listingType)) {
    return initialFailure('Choose a listing type.')
  }
  if (!['published', 'draft'].includes(status)) {
    return initialFailure('Choose published or draft.')
  }

  const payload = await getPayload({ config })
  try {
    const existing = await payload.findByID({
      collection: 'jobs',
      id: jobId,
      depth: 0,
      overrideAccess: false,
      user,
    })
    const ownerId = typeof existing.owner === 'object' ? existing.owner?.id : existing.owner
    if (String(ownerId) !== String(user.id)) {
      return initialFailure('You can only edit your own job listings.')
    }

    await payload.update({
      collection: 'jobs',
      id: jobId,
      data: {
        compensation,
        description,
        listingType: listingType as 'hiring' | 'for-hire',
        location,
        status: status as 'published' | 'draft',
        tags: tagsFrom(text(formData, 'tags', 1000)),
        title,
      },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Job listing updated.' }
  } catch {
    return initialFailure('The job listing could not be updated.')
  }
}

export async function deleteJobAction(jobId: string): Promise<ActionState> {
  const user = await appAuth.currentUser()
  if (!user) return initialFailure('Your session has expired. Log in again.')
  if (!jobId || jobId.length > 100) {
    return initialFailure('This job listing could not be identified.')
  }

  const payload = await getPayload({ config })
  try {
    const existing = await payload.findByID({
      collection: 'jobs',
      id: jobId,
      depth: 0,
      overrideAccess: false,
      user,
    })
    const ownerId = typeof existing.owner === 'object' ? existing.owner?.id : existing.owner
    if (String(ownerId) !== String(user.id)) {
      return initialFailure('You can only remove your own job listings.')
    }

    await payload.delete({
      collection: 'jobs',
      id: jobId,
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Job listing removed.' }
  } catch {
    return initialFailure('The job listing could not be removed.')
  }
}

export async function updatePasswordAction(
  _previous: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const user = await appAuth.currentUser()
  if (!user) return initialFailure('Your session has expired. Log in again.')
  const currentPassword = text(formData, 'currentPassword', 200)
  const newPassword = text(formData, 'newPassword', 200)
  const confirmPassword = text(formData, 'confirmPassword', 200)
  if (!currentPassword) return initialFailure('Enter your current password.')
  if (newPassword.length < 8) return initialFailure('Use at least 8 characters.')
  if (newPassword !== confirmPassword) {
    return initialFailure('The new passwords do not match.')
  }
  if (currentPassword === newPassword) {
    return initialFailure('Choose a new password that differs from your current password.')
  }

  const payload = await getPayload({ config })
  try {
    const verified = await payload.login({
      collection: 'users',
      data: { email: user.email, password: currentPassword },
      overrideAccess: false,
    })
    if (!verified.user || String(verified.user.id) !== String(user.id)) {
      return initialFailure('Your current password is incorrect.')
    }
    await payload.update({
      collection: 'users',
      id: user.id,
      data: { password: newPassword },
      overrideAccess: false,
      user,
    })
    return { ok: true, message: 'Password updated.' }
  } catch {
    return initialFailure('Your current password is incorrect.')
  }
}
