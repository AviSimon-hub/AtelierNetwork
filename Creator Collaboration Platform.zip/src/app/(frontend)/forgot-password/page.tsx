import type { Metadata } from 'next'
import SiteHeader from '@/components/SiteHeader'
import PasswordResetRequestForm from './PasswordResetRequestForm'

export const metadata: Metadata = {
  title: 'Forgot password | Atelier Network',
  description: 'Request a secure password reset link for your Atelier Network account.',
}

export default function ForgotPasswordPage() {
  return (
    <>
      <SiteHeader active="account" />
      <main className="mx-auto w-[min(760px,calc(100%-40px))] py-12 md:py-20">
        <section className="border-t-[10px] border-[#00a4ef] bg-white p-7 shadow-[12px_12px_0_#7b4ab5] md:p-12">
          <PasswordResetRequestForm />
        </section>
      </main>
    </>
  )
}
