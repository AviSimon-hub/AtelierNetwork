'use client'

import Link from 'next/link'
import { useActionState } from 'react'
import {
  requestPasswordResetAction,
  type PasswordActionState,
} from '@/app/(frontend)/password-actions'

const initialState: PasswordActionState = { ok: false, message: '' }

export default function PasswordResetRequestForm() {
  const [state, formAction, pending] = useActionState(requestPasswordResetAction, initialState)

  return (
    <form action={formAction} className="grid gap-5">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#7b4ab5]">
          Account recovery
        </p>
        <h1 className="mt-2 text-4xl font-extralight text-[#252525]">Forgot your password?</h1>
        <p className="mt-3 max-w-lg text-sm leading-6 text-[#657477]">
          Enter the email connected to your account. If it matches a member, we’ll send a one-hour
          reset link.
        </p>
      </div>
      <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
        Email
        <input
          aria-invalid={state.fieldErrors?.email ? true : undefined}
          className="account-input"
          name="email"
          type="email"
          autoComplete="email"
          required
        />
        {state.fieldErrors?.email ? (
          <span className="font-normal normal-case tracking-normal text-[#b3310d]">
            {state.fieldErrors.email}
          </span>
        ) : null}
      </label>
      <button className="account-primary justify-self-start" disabled={pending} type="submit">
        {pending ? 'Sending…' : 'Send reset link'}
      </button>
      {state.message ? (
        <p
          className={`border-l-4 px-4 py-3 text-sm ${
            state.ok
              ? 'border-[#7fba00] bg-[#eef7dd] text-[#365300]'
              : 'border-[#f25022] bg-[#fff0eb] text-[#8b270b]'
          }`}
          role="status"
        >
          {state.message}
        </p>
      ) : null}
      <Link className="text-sm font-semibold text-[#0078b8] hover:underline" href="/account">
        Back to log in
      </Link>
    </form>
  )
}
