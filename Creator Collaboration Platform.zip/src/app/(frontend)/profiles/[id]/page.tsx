import config from '@payload-config'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { connection } from 'next/server'
import { getPayload } from 'payload'
import SiteHeader from '@/components/SiteHeader'

export default async function PublicProfilePage({ params }: { params: Promise<{ id: string }> }) {
  await connection()
  const { id } = await params
  const payload = await getPayload({ config })
  const user = await payload.findByID({
    collection: 'users',
    id,
    depth: 1,
    disableErrors: true,
    overrideAccess: false,
  })
  if (!user) notFound()

  const portfolio = (user.portfolio ?? []).filter((item) => typeof item === 'object')

  return (
    <>
      <SiteHeader active={user.role === 'organization' ? 'organizations' : 'creators'} />
      <main className="detail-page">
        <div className="breadcrumbs">
          <Link href="/">home</Link> ›{' '}
          <Link href={user.role === 'organization' ? '/organizations' : '/creators'}>
            {user.role === 'organization' ? 'organizations' : 'creators'}
          </Link>{' '}
          › {user.name}
        </div>
        <div className="detail-card">
          {(user.noticeTitle || user.noticeBody) && (
            <aside className="bulletin-board" aria-label={`${user.name}'s notice board`}>
              <div className="bulletin-label">notice board</div>
              <div>
                {user.noticeTitle && <strong>{user.noticeTitle}</strong>}
                {user.noticeBody && <p>{user.noticeBody}</p>}
              </div>
            </aside>
          )}
          <div className="profile-heading">
            {user.profileImage && typeof user.profileImage === 'object' && user.profileImage.url ? (
              <Image
                className="h-24 w-24 shrink-0 object-cover"
                src={user.profileImage.url}
                alt={user.profileImage.alt || `${user.name} profile image`}
                width={user.profileImage.width || 320}
                height={user.profileImage.height || 320}
              />
            ) : (
              <div className="grid h-24 w-24 shrink-0 place-items-center bg-[#7b4ab5] text-3xl font-light text-white">
                {user.name.slice(0, 1).toUpperCase()}
              </div>
            )}
            <div>
              <p className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-[#657477]">
                {user.role} profile
              </p>
              <div className="flex flex-wrap items-center gap-3">
                <h1>{user.name}</h1>
                {user.role === 'creator' && user.availableForWork ? (
                  <span className="status">available for work</span>
                ) : null}
              </div>
              {user.location && <p>{user.location}</p>}
            </div>
          </div>
          <section>
            <h2>about</h2>
            <p>{user.description || 'This member has not added a description yet.'}</p>
          </section>
          <section>
            <h2>skills and tags</h2>
            {(user.tags ?? []).length ? (
              <div className="tags large-tags">
                {(user.tags ?? []).map((item) => (
                  <Link
                    href={`/${user.role === 'organization' ? 'organizations' : 'creators'}?tag=${encodeURIComponent(item.tag)}`}
                    key={item.id || item.tag}
                  >
                    {item.tag}
                  </Link>
                ))}
              </div>
            ) : (
              <p className="help-text">No tags added yet.</p>
            )}
          </section>
          <section>
            <h2>portfolio</h2>
            {portfolio.length ? (
              <div className="media-grid">
                {portfolio.map((item) => (
                  <figure className="media-item uploaded-media" key={String(item.id)}>
                    {item.mimeType?.startsWith('image/') && item.url ? (
                      <Image
                        className="h-56 w-full object-cover"
                        src={item.url}
                        alt={item.alt || item.filename || 'Portfolio work'}
                        width={item.width || 640}
                        height={item.height || 480}
                      />
                    ) : item.mimeType?.startsWith('video/') && item.url ? (
                      <video
                        controls
                        src={item.url}
                        aria-label={item.alt || item.filename || 'Portfolio video'}
                      />
                    ) : item.url ? (
                      <audio
                        controls
                        src={item.url}
                        aria-label={item.alt || item.filename || 'Portfolio audio'}
                      />
                    ) : null}
                    <figcaption>{item.alt || item.filename || 'Portfolio work'}</figcaption>
                  </figure>
                ))}
              </div>
            ) : (
              <p className="help-text">No portfolio media added yet.</p>
            )}
          </section>
        </div>
      </main>
    </>
  )
}
