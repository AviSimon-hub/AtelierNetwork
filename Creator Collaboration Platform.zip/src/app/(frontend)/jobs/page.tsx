import config from '@payload-config'
import Link from 'next/link'
import { connection } from 'next/server'
import { getPayload } from 'payload'
import SiteHeader from '@/components/SiteHeader'
import JobFilters from './JobFilters'

export default async function JobsPage({
  searchParams,
}: {
  searchParams: Promise<{ location?: string; q?: string; tag?: string | string[] }>
}) {
  await connection()
  const params = await searchParams
  const query = params.q?.trim() ?? ''
  const location = params.location?.trim() ?? ''
  const selectedTags = Array.isArray(params.tag) ? params.tag : params.tag ? [params.tag] : []
  const payload = await getPayload({ config })
  const [result, optionsResult] = await Promise.all([
    payload.find({
      collection: 'jobs',
      depth: 0,
      limit: 100,
      overrideAccess: false,
      sort: '-createdAt',
      where: {
        and: [
          ...(query
            ? [
                {
                  or: [
                    { title: { contains: query } },
                    { posterName: { contains: query } },
                    { location: { contains: query } },
                    { description: { contains: query } },
                  ],
                },
              ]
            : []),
          ...(location ? [{ location: { contains: location } }] : []),
          ...selectedTags.map((tag) => ({ 'tags.tag': { equals: tag } })),
        ],
      },
    }),
    payload.find({
      collection: 'jobs',
      depth: 0,
      limit: 100,
      overrideAccess: false,
      select: {
        location: true,
        tags: true,
      },
    }),
  ])
  const allTags = [
    ...new Set(
      optionsResult.docs.flatMap((job) =>
        (job.tags ?? []).map((item) => item.tag).filter((tag): tag is string => Boolean(tag)),
      ),
    ),
  ].sort()
  const allLocations = [
    ...new Set(optionsResult.docs.map((job) => job.location).filter(Boolean)),
  ].sort()

  return (
    <>
      <SiteHeader active="jobs" />
      <main className="results-page">
        <div className="breadcrumbs">
          <Link href="/">home</Link> › jobs
        </div>
        <div className="results-layout">
          <JobFilters locations={allLocations} tags={allTags} />
          <section className="results-list">
            <div className="results-heading">
              <h1>jobs</h1>
              <span>
                {result.docs.length} result{result.docs.length === 1 ? '' : 's'}
              </span>
            </div>
            {(selectedTags.length > 0 || location) && (
              <div className="active-filters">
                filtered by: {[location, ...selectedTags].filter(Boolean).join(', ')}{' '}
                <Link className="ml-2 text-xs" href="/jobs">
                  clear
                </Link>
              </div>
            )}
            {!result.docs.length && (
              <p className="empty">
                No matching listings. Try removing a tag or changing your search.
              </p>
            )}
            {result.docs.map((job) => (
              <article className="listing job-listing" key={String(job.id)}>
                <time>
                  <strong
                    className={`listing-type ${job.listingType === 'for-hire' ? 'for-hire' : ''}`}
                  >
                    {job.listingType === 'for-hire' ? 'for hire' : 'hiring'}
                  </strong>
                  {new Date(job.createdAt).toLocaleDateString()}
                </time>
                <div>
                  <h2>
                    <Link href={`/jobs/${job.slug}`}>{job.title}</Link>
                  </h2>
                  <p className="listing-meta">
                    {job.posterName} · {job.location} · {job.compensation}
                  </p>
                  <p>{job.description}</p>
                  <div className="tags">
                    {(job.tags ?? []).map((item) =>
                      item.tag ? (
                        <Link href={`/jobs?tag=${encodeURIComponent(item.tag)}`} key={item.tag}>
                          {item.tag}
                        </Link>
                      ) : null,
                    )}
                  </div>
                </div>
              </article>
            ))}
          </section>
        </div>
      </main>
    </>
  )
}
