'use client'

import { useRouter, useSearchParams } from 'next/navigation'
import { useMemo, useState } from 'react'

function addValue(current: URLSearchParams, key: string, value: string) {
  const next = new URLSearchParams(current.toString())
  next.delete(key)
  if (value) next.set(key, value)
  return next
}

export default function JobFilters({ locations, tags }: { locations: string[]; tags: string[] }) {
  const router = useRouter()
  const params = useSearchParams()
  const selectedLocation = params.get('location') ?? ''
  const selectedTag = params.get('tag') ?? ''
  const [locationQuery, setLocationQuery] = useState(selectedLocation)
  const [tagQuery, setTagQuery] = useState(selectedTag)

  const matchingLocations = useMemo(
    () =>
      locations.filter((location) =>
        location.toLowerCase().includes(locationQuery.trim().toLowerCase()),
      ),
    [locationQuery, locations],
  )
  const matchingTags = useMemo(
    () => tags.filter((tag) => tag.toLowerCase().includes(tagQuery.trim().toLowerCase())),
    [tagQuery, tags],
  )

  const apply = (key: 'location' | 'tag', value: string) => {
    router.push(`/jobs?${addValue(new URLSearchParams(params.toString()), key, value).toString()}`)
  }

  const clearAll = () => {
    setLocationQuery('')
    setTagQuery('')
    router.push('/jobs')
  }

  return (
    <aside className="filters">
      <div className="panel-title">filter jobs</div>
      <button
        className={`all-tags ${!selectedLocation && !selectedTag ? 'active' : ''}`}
        onClick={clearAll}
        type="button"
      >
        all jobs
      </button>
      <div className="filter-groups">
        <details className="filter-group" open>
          <summary>
            Location <span>{matchingLocations.length}</span>
          </summary>
          <div className="tag-search">
            <label htmlFor="job-location-filter">type a place</label>
            <input
              id="job-location-filter"
              value={locationQuery}
              onChange={(event) => setLocationQuery(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter') apply('location', locationQuery.trim())
              }}
              placeholder="city, region, or remote"
            />
          </div>
          <div className="max-h-52 overflow-y-auto py-1">
            {matchingLocations.length ? (
              matchingLocations.map((location) => (
                <button
                  className={`block w-full px-4 py-2 text-left text-[11px] text-[#0078b8] hover:bg-[#dff2f8] ${
                    selectedLocation === location ? 'bg-[#dff2f8] font-bold' : ''
                  }`}
                  key={location}
                  onClick={() => {
                    setLocationQuery(location)
                    apply('location', location)
                  }}
                  type="button"
                >
                  {location}
                </button>
              ))
            ) : (
              <button
                className="block w-full px-4 py-3 text-left text-[11px] text-[#0078b8]"
                onClick={() => apply('location', locationQuery.trim())}
                type="button"
              >
                search for “{locationQuery.trim()}”
              </button>
            )}
          </div>
        </details>

        <details className="filter-group" open>
          <summary>
            Listing tag <span>{matchingTags.length}</span>
          </summary>
          <div className="tag-search">
            <label htmlFor="job-tag-filter">find a tag</label>
            <input
              id="job-tag-filter"
              value={tagQuery}
              onChange={(event) => setTagQuery(event.target.value)}
              placeholder="try “music” or “remote”"
            />
          </div>
          <div className="max-h-52 overflow-y-auto py-1">
            {matchingTags.length ? (
              matchingTags.map((tag) => (
                <button
                  className={`block w-full px-4 py-2 text-left text-[11px] text-[#0078b8] hover:bg-[#dff2f8] ${
                    selectedTag === tag ? 'bg-[#dff2f8] font-bold' : ''
                  }`}
                  key={tag}
                  onClick={() => {
                    setTagQuery(tag)
                    apply('tag', tag)
                  }}
                  type="button"
                >
                  {tag}
                </button>
              ))
            ) : (
              <p className="px-4 py-3 text-[11px] text-[#657477]">no matching tags</p>
            )}
          </div>
        </details>
      </div>
    </aside>
  )
}
