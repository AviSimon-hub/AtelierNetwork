import Link from 'next/link'
import { notFound } from 'next/navigation'
import { connection } from 'next/server'
import SiteHeader from '@/components/SiteHeader'
import { findBySlug } from '@/lib/payload'

export default async function JobDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  await connection()
  const { slug } = await params
  const job = await findBySlug('jobs', slug, { depth: 1 })
  if (!job) notFound()

  return (
    <>
      <SiteHeader active="jobs" />
      <main className="detail-page">
        <div className="breadcrumbs">
          <Link href="/">home</Link> › <Link href="/jobs">jobs</Link> › {job.title}
        </div>
        <div className="detail-card job-detail">
          <p className="eyebrow">
            <strong className={`listing-type ${job.listingType === 'for-hire' ? 'for-hire' : ''}`}>
              {job.listingType === 'for-hire' ? 'for hire' : 'hiring'}
            </strong>
            {new Date(job.createdAt).toLocaleDateString()} · {job.location}
          </p>
          <h1>{job.title}</h1>
          <p className="company">posted by {job.posterName}</p>
          <dl>
            <div>
              <dt>compensation</dt>
              <dd>{job.compensation}</dd>
            </div>
            <div>
              <dt>location</dt>
              <dd>{job.location}</dd>
            </div>
          </dl>
          <section>
            <h2>about this job</h2>
            <p>{job.description}</p>
          </section>
          <div className="tags large-tags">
            {(job.tags ?? []).map((item) =>
              item.tag ? (
                <Link href={`/jobs?tag=${encodeURIComponent(item.tag)}`} key={item.tag}>
                  {item.tag}
                </Link>
              ) : null,
            )}
          </div>
          <Link className="contact-button inline-flex items-center" href="/account">
            {job.listingType === 'hiring'
              ? 'reply to this opportunity'
              : `contact ${job.posterName.split(' ')[0].toLowerCase()}`}
          </Link>
        </div>
      </main>
    </>
  )
}
