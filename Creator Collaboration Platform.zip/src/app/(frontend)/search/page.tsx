import { Suspense } from 'react'
import { connection } from 'next/server'
import LegacySite from '@/components/LegacySite'
import { getRegisteredProfiles } from '@/lib/public-profiles'

export default async function SearchPage() {
  await connection()
  const profiles = await getRegisteredProfiles()
  return (
    <Suspense>
      <LegacySite registeredProfiles={profiles} />
    </Suspense>
  )
}
