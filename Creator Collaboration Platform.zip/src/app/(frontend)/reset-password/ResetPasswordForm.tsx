'use client'

import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { useActionState, useEffect, useState } from 'react'
import { resetPasswordAction, type PasswordActionState } from '@/app/(frontend)/password-actions'

const initialState: PasswordActionState = { ok: false, message: '' }

function PasswordInput({ error, label, name }: { error?: string; label: string; name: string }) {
  const [visible, setVisible] = useState(false)

  return (
    <label className="grid gap-2 text-xs font-semibold uppercase tracking-wider text-[#53666b]">
      {label}
      <span className="relative block">
        <input
          aria-invalid={error ? true : undefined}
          className="account-input pr-14"
          name={name}
          type={visible ? 'text' : 'password'}
          autoComplete="new-password"
          minLength={8}
          required
        />
        <button
          className="absolute inset-y-0 right-0 px-3 text-xs font-semibold text-[#0078b8]"
          onClick={() => setVisible((current) => !current)}
          type="button"
        >
          {visible ? 'Hide' : 'Show'}
        </button>
      </span>
      {error ? (
        <span className="font-normal normal-case tracking-normal text-[#b3310d]">{error}</span>
      ) : null}
    </label>
  )
}

export default function ResetPasswordForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const token = searchParams.get('token') ?? ''
  const [state, formAction, pending] = useActionState(resetPasswordAction, initialState)

  useEffect(() => {
    if (!state.ok) return
    const timeout = window.setTimeout(() => {
      router.push('/account')
      router.refresh()
    }, 700)
    return () => window.clearTimeout(timeout)
  }, [router, state.ok])

  if (!/^[a-f0-9]{40}$/i.test(token)) {
    return (
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#f25022]">
          Invalid reset link
        </p>
        <h1 className="mt-2 text-4xl font-extralight text-[#252525]">Request a new link</h1>
        <p className="mt-4 text-sm leading-6 text-[#657477]">
          This password reset link is incomplete or invalid. Start again to receive a fresh one-hour
          link.
        </p>
        <Link
          className="mt-6 inline-block bg-[#f25022] px-5 py-3 text-xs font-semibold uppercase tracking-wider text-white no-underline"
          href="/forgot-password"
        >
          Request reset link
        </Link>
      </div>
    )
  }

  return (
    <form action={formAction} className="grid gap-5">
      <input name="token" type="hidden" value={token} />
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#7b4ab5]">
          Account recovery
        </p>
        <h1 className="mt-2 text-4xl font-extralight text-[#252525]">Choose a new password</h1>
        <p className="mt-3 text-sm leading-6 text-[#657477]">
          Use at least 8 characters. Completing this reset signs out your other sessions.
        </p>
      </div>
      <PasswordInput error={state.fieldErrors?.password} label="New password" name="password" />
      <PasswordInput
        error={state.fieldErrors?.confirmPassword}
        label="Confirm new password"
        name="confirmPassword"
      />
      <button className="account-primary justify-self-start" disabled={pending} type="submit">
        {pending ? 'Resetting…' : 'Reset password'}
      </button>
      {state.message ? (
        <p
          className={`border-l-4 px-4 py-3 text-sm ${
            state.ok
              ? 'border-[#7fba00] bg-[#eef7dd] text-[#365300]'
              : 'border-[#f25022] bg-[#fff0eb] text-[#8b270b]'
          }`}
          role="status"
        >
          {state.message}
        </p>
      ) : null}
    </form>
  )
}
