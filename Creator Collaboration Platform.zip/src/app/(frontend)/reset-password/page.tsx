import type { Metadata } from 'next'
import { Suspense } from 'react'
import SiteHeader from '@/components/SiteHeader'
import ResetPasswordForm from './ResetPasswordForm'

export const metadata: Metadata = {
  title: 'Reset password | Atelier Network',
  description: 'Choose a new password for your Atelier Network account.',
}

export default function ResetPasswordPage() {
  return (
    <>
      <SiteHeader active="account" />
      <main className="mx-auto w-[min(760px,calc(100%-40px))] py-12 md:py-20">
        <section className="border-t-[10px] border-[#00a4ef] bg-white p-7 shadow-[12px_12px_0_#7b4ab5] md:p-12">
          <Suspense fallback={<p className="text-sm text-[#657477]">Checking reset link…</p>}>
            <ResetPasswordForm />
          </Suspense>
        </section>
      </main>
    </>
  )
}
