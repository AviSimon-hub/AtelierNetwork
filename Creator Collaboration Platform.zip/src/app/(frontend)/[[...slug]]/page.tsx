import LegacySite from '@/components/LegacySite'
import { Suspense } from 'react'

export const dynamicParams = false

export function generateStaticParams() {
  return [{ slug: undefined }]
}

export default function LegacyPage() {
  return (
    <Suspense
      fallback={
        <main className="home-page">
          <p className="text-sm text-[#657477]">Loading Atelier Network…</p>
        </main>
      }
    >
      <LegacySite />
    </Suspense>
  )
}
