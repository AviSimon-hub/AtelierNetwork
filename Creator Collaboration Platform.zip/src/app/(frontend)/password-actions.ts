'use server'

import config from '@payload-config'
import { getPayload } from 'payload'
import { appAuth } from '@/lib/app-auth'

export type PasswordActionState = {
  ok: boolean
  message: string
  fieldErrors?: Record<string, string>
}

const failure = (message: string): PasswordActionState => ({ ok: false, message })

function text(formData: FormData, key: string, max: number) {
  const value = formData.get(key)
  return typeof value === 'string' ? value.trim().slice(0, max) : ''
}

export async function requestPasswordResetAction(
  _previous: PasswordActionState,
  formData: FormData,
): Promise<PasswordActionState> {
  const email = text(formData, 'email', 200).toLowerCase()
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return {
      ok: false,
      message: 'Enter a valid email address.',
      fieldErrors: { email: 'Enter a valid email address.' },
    }
  }

  if (!process.env.RESEND_API_KEY || !process.env.RESEND_FROM_EMAIL) {
    return failure(
      'Password reset email is not active yet. Contact the site owner or try again after email delivery is configured.',
    )
  }

  try {
    const payload = await getPayload({ config })
    await payload.forgotPassword({
      collection: 'users',
      data: { email },
      overrideAccess: true,
    })
    return {
      ok: true,
      message:
        'If an account uses that email, a reset link is on its way. Check your inbox and spam folder.',
    }
  } catch {
    return failure('Reset email could not be sent right now. Please try again later.')
  }
}

export async function resetPasswordAction(
  _previous: PasswordActionState,
  formData: FormData,
): Promise<PasswordActionState> {
  const token = text(formData, 'token', 100)
  const password = text(formData, 'password', 200)
  const confirmPassword = text(formData, 'confirmPassword', 200)
  const fieldErrors: Record<string, string> = {}

  if (!/^[a-f0-9]{40}$/i.test(token)) {
    return failure('This reset link is invalid. Request a new password reset email.')
  }
  if (password.length < 8) fieldErrors.password = 'Use at least 8 characters.'
  if (password !== confirmPassword) {
    fieldErrors.confirmPassword = 'The passwords do not match.'
  }
  if (Object.keys(fieldErrors).length) {
    return { ok: false, message: 'Please correct the highlighted fields.', fieldErrors }
  }

  try {
    const payload = await getPayload({ config })
    const result = await payload.resetPassword({
      collection: 'users',
      data: { password, token },
      overrideAccess: false,
    })
    if (!result.token) return failure('Your password changed, but sign-in could not be completed.')

    await appAuth.setSessionToken(result.token)
    return { ok: true, message: 'Password reset. Taking you to your account…' }
  } catch {
    return failure('This reset link is invalid or has expired. Request a new one and try again.')
  }
}
